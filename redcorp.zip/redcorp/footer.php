<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package redcorp
 */

?>

	<div class="col-md-12 col-sm-12 col-xs-12 padding_zero footer_bg wow fadeInUp animated" data-wow-duration="0.7s">
<div class="look_layer"></div>
    <div class="container">
        <div class="col-md-12 col-sm-12 col-xs-12 padding_zero">
            <div class="col-md-4 col-sm-4 col-xs-12">
               <?php
                  if(ot_get_option('footer_logo')!=='')
                  {
                    echo '<div class="col-md-12 col-sm-12 col-xs-12 padding_zero logo"><a class="logo white" href="'.get_site_url().'"><img src="'.ot_get_option('footer_logo').'" alt="footer logo"></a></div>';
                  }
                ?>
                 
                <?php
                  if(ot_get_option('footer_about_text')!=='')
                  {
                    echo '<p class="footer_about_para">'.ot_get_option('footer_about_text').'</p>';
                  }
                ?>
                 
            </div>

            <div class="col-md-4 col-sm-4 col-xs-12 margin_top_media">
            
                <?php
                      if (is_active_sidebar('footer_area_widget')) {
                        dynamic_sidebar('footer_area_widget');
                      }
                 ?>

            </div>

            <div class="col-md-4 col-sm-4 col-xs-12 margin_top_media">
                <p class="footer_title">Contact Info</p>

                <?php
                   if(ot_get_option('address')!=='')
                                    {
                                      echo '<p>'.ot_get_option('address').'</p>';
                                    }
                ?>
                

                <ul class="list mt-5">
                <?php 
                    if(ot_get_option('top_header_contact_number')!=='')
                    {
                      echo '<li class="m-0 pl-10 pr-10"><a href="#" class="hvr-buzz-out"> <i class="fa fa-phone text-theme-color-2 mr-5"></i> </a><a class="text-gray" href="tel:'.ot_get_option('top_header_contact_number').'">'.ot_get_option('top_header_contact_number').'</a> </li>';
                    }

                    if(ot_get_option('top_header_email')!=='')
                    {
                      echo '<br/><li class="m-0 pl-10 pr-10"> <a href="#" class="hvr-buzz-out"> <i class="fa fa-envelope-o text-theme-color-2 mr-5"></i></a> <a class="text-gray" href="mailto:'.ot_get_option('top_header_email').'">'.ot_get_option('top_header_email').'</a> </li>';
                    } 

                     if(ot_get_option('website')!=='')
                    {
                      echo '<br/><li class="m-0 pl-10 pr-10"> <a href="#" class="hvr-buzz-out"> <i class="fa fa-globe text-theme-color-2 mr-5"></i></a> <a class="text-gray" target="_blank" href="//'.ot_get_option('website').'">'.ot_get_option('website').'</a></li>';
                    } 
                ?>
     
                        
                        
                        
                </ul>

                <ul class="styled-icons icon-bordered icon-sm">
                  <?php
                    if ( function_exists( 'ot_get_option' ) ) {
                      $social_media_icons = ot_get_option( 'social_media_icons' );
                    };
                  ?>
                  <?php 
                    if ( $social_media_icons ) {
                      foreach ( $social_media_icons as $key=>$icon ) {
                        if ( $icon['href'] && $icon['icon']) {
                          echo '<li><a target="_blank" href="'. $icon['href'].'" class="hvr-bounce-to-right"><i class="'.$icon['icon'].'"></i></a></li>';
                        }
                      }
                    }
                  ?>
                </ul>
            </div>
        </div>
    </div>
</div>


<?php
  if(ot_get_option('copyright')!=='')
  {
    echo '<div class="col-md-12 col-snm-12 col-xs-12 padding_zero text-center footer_copy_bg"><p>Copyright &copy '.ot_get_option('copyright').'</p></div>';
  }  
?> 


<!-- <a href="javascript:" id="return-to-top"><i class="fa fa-chevron-up" aria-hidden="true"></i></a> -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- team hover -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
 <script type="text/javascript" src="<?php bloginfo('template_url') ?>/js/wow.min.js"></script>
<script>
    new WOW().init();
</script>
<script type="text/javascript">
  $(document).ready(function(){
    $("#testimonial-slider").owlCarousel({
        items:2,
        itemsDesktop:[1000,2],
        itemsDesktopSmall:[990,1],
        itemsTablet:[768,1],
        pagination:true,
        navigation:false,
        navigationText:["",""],
        slideSpeed:1000,
        autoPlay:true
    });
});
</script>

 <!-- counter -->
<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script> 
<script src="<?php bloginfo('template_url') ?>/js/jquery.counterup.min.js"></script> 
<script type="text/javascript">
    var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-36251023-1']);
        _gaq.push(['_setDomainName', 'jqueryscript.net']);
        _gaq.push(['_trackPageview']);
         
        (function() {
           var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
           ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
           var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
        })();
</script>
<script>
    jQuery(document).ready(function( $ ) {
      $('.counter').counterUp({
        delay: 10,
        time: 1000
      });
    });
</script>
      <!-- counter -->

<!-- ===== Scroll to Top ==== -->
<script type="text/javascript">
$(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('#return-to-top').fadeIn(200);    // Fade in the arrow
    } else {
        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
    }
});
$('#return-to-top').click(function() {      // When arrow is clicked
    $('body,html').animate({
        scrollTop : 0                       // Scroll to top of body
    }, 500);
});
</script>

<!-- menu -->
<script>
(function($) {
$.fn.menumaker = function(options) {  
 var cssmenu = $(this), settings = $.extend({
   format: "dropdown",
   sticky: false
 }, options);
 return this.each(function() {
   $(this).find(".button").on('click', function(){
     $(this).toggleClass('menu-opened');
     var mainmenu = $(this).next(".menu-menu-1-container").find('.menu');
     if (mainmenu.hasClass('open')) { 
       mainmenu.slideToggle().removeClass('open');
     }
     else {
       mainmenu.slideToggle().addClass('open');
       if (settings.format === "dropdown") {
         mainmenu.find('ul').show();
       }
     }
   });
   cssmenu.find('li ul').parent().addClass('has-sub');
multiTg = function() {
     cssmenu.find(".has-sub").prepend('<span class="submenu-button"></span>');
     cssmenu.find('.submenu-button').on('click', function() {
       $(this).toggleClass('submenu-opened');
       if ($(this).siblings('ul').hasClass('open')) {
         $(this).siblings('ul').removeClass('open').slideToggle();
       }
       else {
         $(this).siblings('ul').addClass('open').slideToggle();
       }
     });
   };
   if (settings.format === 'multitoggle') multiTg();
   else cssmenu.addClass('dropdown');
   if (settings.sticky === true) cssmenu.css('position', 'fixed');
resizeFix = function() {
  var mediasize = 991;
     if ($( window ).width() > mediasize) {
       cssmenu.find('ul').show();
     }
     if ($(window).width() <= mediasize) {
       cssmenu.find('ul').hide().removeClass('open');
     }
   };
   resizeFix();
   return $(window).on('resize', resizeFix);
 });
  };
})(jQuery);

(function($){
$(document).ready(function(){
$("#cssmenu").menumaker({
   format: "multitoggle"
});
});
})(jQuery);

</script>
<!-- menu -->

<!-- gallary -->
<script type="text/javascript">
  $(document).ready(function(){

    $(".filter-button").click(function(){
        var value = $(this).attr('data-filter');
        
        if(value == "all")
        {
            //$('.filter').removeClass('hidden');
            $('.filter').show('1000');
        }
        else
        {
//            $('.filter[filter-item="'+value+'"]').removeClass('hidden');
//            $(".filter").not('.filter[filter-item="'+value+'"]').addClass('hidden');
            $(".filter").not('.'+value).hide('3000');
            $('.filter').filter('.'+value).show('3000');
            
        }
    });
    
    if ($(".filter-button").removeClass("active")) {
$(this).removeClass("active");
}
$(this).addClass("active");

});
</script>
<!-- gallary -->

<!-- progress -->
<script type="text/javascript">
  jQuery(document).ready(function(){
  jQuery('.skillbar').each(function(){
    jQuery(this).find('.skillbar-bar').animate({
      width:jQuery(this).attr('data-percent')
    },6000);
  });
});
</script>

<!-- search btn -->
<script type="text/javascript">
( function( window ) {

'use strict';

// class helper functions from bonzo https://github.com/ded/bonzo

function classReg( className ) {
  return new RegExp("(^|\\s+)" + className + "(\\s+|$)");
}

// classList support for class management
// altho to be fair, the api sucks because it won't accept multiple classes at once
var hasClass, addClass, removeClass;

if ( 'classList' in document.documentElement ) {
  hasClass = function( elem, c ) {
    return elem.classList.contains( c );
  };
  addClass = function( elem, c ) {
    elem.classList.add( c );
  };
  removeClass = function( elem, c ) {
    elem.classList.remove( c );
  };
}
else {
  hasClass = function( elem, c ) {
    return classReg( c ).test( elem.className );
  };
  addClass = function( elem, c ) {
    if ( !hasClass( elem, c ) ) {
      elem.className = elem.className + ' ' + c;
    }
  };
  removeClass = function( elem, c ) {
    elem.className = elem.className.replace( classReg( c ), ' ' );
  };
}

function toggleClass( elem, c ) {
  var fn = hasClass( elem, c ) ? removeClass : addClass;
  fn( elem, c );
}

var classie = {
  // full names
  hasClass: hasClass,
  addClass: addClass,
  removeClass: removeClass,
  toggleClass: toggleClass,
  // short names
  has: hasClass,
  add: addClass,
  remove: removeClass,
  toggle: toggleClass
};

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( classie );
} else {
  // browser global
  window.classie = classie;
}

})( window );

(function(window){

  // get vars
  var searchEl = document.querySelector("#input");
  var labelEl = document.querySelector("#label");

  // register clicks and toggle classes
  labelEl.addEventListener("click",function(){
    if (classie.has(searchEl,"focus")) {
      classie.remove(searchEl,"focus");
      classie.remove(labelEl,"active");
    } else {
      classie.add(searchEl,"focus");
      classie.add(labelEl,"active");
    }
  });

  // register clicks outisde search box, and toggle correct classes
  document.addEventListener("click",function(e){
    var clickedID = e.target.id;
    if (clickedID != "search-terms" && clickedID != "search-label") {
      if (classie.has(searchEl,"focus")) {
        classie.remove(searchEl,"focus");
        classie.remove(labelEl,"active");
      }
    }
  });
}(window));
</script>
<!-- search btn -->

<?php wp_footer(); ?>

</body>
</html>
