<?php
/*
Plugin Name: Recent Post With Thumbnail Widget
Plugin URI: http://rajkumar.me/
Description: Recent Post With Thumbnail Widget
Author: Rajkumar Gadhavi
Version: 1
Author URI: http://rajkumar.me/
*/


class RecentPostWidget extends WP_Widget
{
  function RecentPostWidget()
  {
    $widget_ops = array('classname' => 'RecentPostWidget', 'description' => 'Displays a Recent post with thumbnail For Footer' );
    $this->WP_Widget('RecentPostWidget', 'Recent Post and Thumbnail Footer', $widget_ops);
  }
 
  function form($instance)
  {
    $instance = wp_parse_args( (array) $instance, array( 'title' => '' ) );
    $title = $instance['title'];
?>
  <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></label></p>
<?php
  }
 
  function update($new_instance, $old_instance)
  {
    $instance = $old_instance;
    $instance['title'] = $new_instance['title'];
    return $instance;
  }
 
  function widget($args, $instance)
  {
    extract($args, EXTR_SKIP);
 
    echo $before_widget;
    $title = empty($instance['title']) ? ' ' : apply_filters('widget_title', $instance['title']);
 
    if (!empty($title))
      echo '<p class="footer_title">'.$title.'</p>';
 
    // WIDGET CODE GOES HERE

query_posts('posts_per_page=2');
if (have_posts()) : 
  echo "";
  while (have_posts()) : the_post(); 
?>
          <div class="col-md-12 col-sm-12 col-xs-12 padding_zero read_margin_bottom">
            <div class="col-md-4 col-sm-4 col-xs-12 padding_left">
                 <div class="hover01 column">
                    <div>
                        <figure><img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?>" class="img_width footer_img"></figure>
                    </div>
                 </div>
            </div>

            <div class="col-md-8 col-sm-8 col-xs-12 padding_zero">
                  <p><a href="<?php echo get_permalink(); ?>" class="footer_a"><?php echo "".get_the_title(); ?></a></p>
                  <p class="sale_price"><?php echo get_the_date('M'); ?> <?php echo get_the_date('d'); ?>, <?php echo get_the_date('Y'); ?></p>
            </div>
        </div>
<?php

      
  endwhile;
  echo "";
endif; 
wp_reset_query();



    echo $after_widget;
  }
 
}
add_action( 'widgets_init', create_function('', 'return register_widget("RecentPostWidget");') );?>




                