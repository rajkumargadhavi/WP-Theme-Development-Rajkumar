<?php
/*
Plugin Name: Popular Post With Thumbnail Widget
Plugin URI: http://rajkumar.me/
Description: Popular Post With Thumbnail Widget
Author: Rajkumar Gadhavi
Version: 1
Author URI: http://rajkumar.me/
*/


class PopularPostWidget extends WP_Widget
{
  function PopularPostWidget()
  {
    $widget_ops = array('classname' => 'PopularPostWidget', 'description' => 'Displays a Popular post with thumbnail For Sidebar' );
    $this->WP_Widget('PopularPostWidget', 'Popular Post and Thumbnail Sidebar', $widget_ops);
  }
 
  function form($instance)
  {
    $instance = wp_parse_args( (array) $instance, array( 'title' => '', 'numofposts' => '') );
    $title = $instance['title'];
    $numofposts = $instance['numofposts'];
?>
  <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></label></p>

   <p><label for="<?php echo $this->get_field_id('numofposts'); ?>">Number Of Posts To Show: <input class="widefat" id="<?php echo $this->get_field_id('numofposts'); ?>" name="<?php echo $this->get_field_name('numofposts'); ?>" type="text" value="<?php echo attribute_escape($numofposts); ?>" /></label></p>

<?php
  }
 
  function update($new_instance, $old_instance)
  {
    $instance = $old_instance;
    $instance['title'] = $new_instance['title'];
    $instance['numofposts'] = $new_instance['numofposts'];
    return $instance;
  }
 
  function widget($args, $instance)
  {
    extract($args, EXTR_SKIP);
 
    echo $before_widget;
    $title = empty($instance['title']) ? ' ' : apply_filters('widget_title', $instance['title']);
 
    if (!empty($title))
      echo '<p class="category_title">'.$title.'</p>';
 
    // WIDGET CODE GOES HERE
$numofposts = empty($instance['numofposts']) ? ' ' : apply_filters('widget_title', $instance['numofposts']);
 
    if (!empty($numofposts))    
query_posts('posts_per_page='.$numofposts.'');


if (have_posts()) : 
  echo "";
  while (have_posts()) : the_post(); 
?>
   
         <div class="populer_post">
                        <div class="post_famous">
                            <div class="col-md-3 col-lg-3 col-sm-3 col-xs-3 padding_zero padding_right_media latest_post_padding">
                                <div class="comment_holders">
                                  <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?>" class="footer_img img-responsive">
                                </div>
                            </div>
                          
                            <div class="col-md-9 col-lg-9 col-sm-9 col-xs-12 padding_right latest_post_padding padding_left_media">
                                <a href="<?php echo get_permalink(); ?>"><p class="post_p"><?php echo "".get_the_title(); ?></p></a>
                                    <p class="comnt_time"><?php echo get_the_date('M'); ?> <?php echo get_the_date('d'); ?>, <?php echo get_the_date('Y'); ?>, <a href="<?php echo get_permalink(); ?>" class=" black"><?php echo get_comments_number(); ?> Comments</a></p>
                                  
                                </div>
                        </div>
                    </div>


<?php

      
  endwhile;
  echo "";
endif; 
wp_reset_query();



    echo $after_widget;
  }
 
}
add_action( 'widgets_init', create_function('', 'return register_widget("PopularPostWidget");') );?>