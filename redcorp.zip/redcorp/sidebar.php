<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package redcorp
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>






                <div class="single_blog_right_part">
                      
                    <div class="blog_search">
                       <div class="form-group">
                       <form role="search" method="get" action="<?php echo home_url('/'); ?>">
                          <input type="text" class="form-control search_img" id="usr" value="<?php echo get_search_query(); ?>" placeholder="Search here" name="s" title="Search">
                          </form>
                        </div>
                    </div>

                  <?php dynamic_sidebar( 'sidebar-1' ); ?>

                    
          

