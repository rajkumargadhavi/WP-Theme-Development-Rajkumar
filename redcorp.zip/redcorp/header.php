<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package redcorp
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
	<!-- animation -->
	<link rel="stylesheet" href="http://cdn.jsdelivr.net/animatecss/2.1.0/animate.min.css">
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url') ?>/css/hover.css">
	<!-- <link rel="stylesheet" type="text/css" href="assets/css/style.css"> -->
<script type="text/javascript">
$(document).ready(function(){
$('#commentform').validate();
});
</script>

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>


<div class="col-md-12 col-sm-12 col-xs-12 margin_top_header top_header_bg top_absoult padding_zero showonmedia">
<div class="container container_padding">
   <div class="col-md-12 col-sm-12 col-xs-12  z-index ">
      <div class="pull-left top_header_margin_top ">
      <?php 
        if(ot_get_option('top_header_email')!=='')
        {
          echo '<i class="fa fa-envelope-o" aria-hidden="true"></i><span class="span_margin_left"><a href="mailto:'.ot_get_option('top_header_email').'">'.ot_get_option('top_header_email').'</a></span>';
        } 

        if(ot_get_option('top_header_email')!=='' && ot_get_option('top_header_contact_number')!=='')
        {
          echo '<span class="span_margin_left"> | </span>';
        }

        if(ot_get_option('top_header_contact_number')!=='')
        {
          echo '<i class="fa fa-mobile span_margin_left" aria-hidden="true"></i><a href="tel:'.ot_get_option('top_header_contact_number').'" class="span_margin_left">'.ot_get_option('top_header_contact_number').'</a> ';
        }
      ?>
     
                  
          
      </div>

        
      <div class=" pull-right pull_left_media  ">
         



<div class= "pull_left_media ">
<?php
  if ( function_exists( 'ot_get_option' ) ) {
    $social_media_icons = ot_get_option( 'social_media_icons' );
  };
?>
  <?php 
    if ( $social_media_icons ) {
      foreach ( $social_media_icons as $key=>$icon ) {
        if ( $icon['href'] && $icon['icon']) {
          echo '<a target="_blank" href="' . $icon['href'] . '" class="hvr-grow-shadow"><i class="'.$icon['icon'] .' header_icon fb " aria-hidden="true"></i></a>';
        }
      }
    }
  ?>  
   </div>
      
   </div>
</div>
</div>
</div>






<div class="col-md-12 col-sm-12 col-xs-12 padding_zero showonmedia">
<div class="container container_padding">
<div class="float-panel" data-top="0" data-scroll="50" >
<div class="container ">
<header class="">
      <nav id='cssmenu'>
        <div class="logo"> <a class="navbar-brand" href="<?php get_site_url(); ?>"><img src="<?php echo ot_get_option('site_logo'); ?>" alt="logo" class="img-responsive"></a></div>
          <div id="head-mobile"></div>
          <div class="button"></div>

          
      <?php
        wp_nav_menu( array(
          'theme_location' => 'menu-1',
          'menu_id'        => 'primary-menu',
        ) );
      ?>
      
      <script type="text/javascript">

var ul = document.querySelector('#primary-menu');
var li = document.createElement('li');

li.innerHTML = '<form id="demo-2" role="search" method="get" action="<?php echo home_url('/'); ?>"><input type="search" placeholder="Search" value="<?php echo get_search_query(); ?>" name="s" title="Search"></form>';
li.className = 'someclass';

ul.appendChild(li);
        // document.getElementById('').appendChild('<li><form id="demo-2"><input type="search" placeholder="Search"></form></li>');
      </script>
</nav>

</header>
</div>
</div>
</div>
</div>


<!-- Breadcrumb Start -->


 <?php 

 if (!is_front_page() && !is_home() && !is_archive() && !is_author() && !is_category() && !is_tag() && !is_search() && !is_404()) {?>

  <div class="col-md-12 col-sm-12 col-xs-12 padding_zero contact_bg" style="background: url(<?php echo ot_get_option('header_background_image'); ?>);">
    <div class="contact_layer"></div>
    <div class="container">
        <div class="col-md-12 col-sm-12 col-xs-12 contact_margin_top">
          <div class="pull-left">
            <p class="contact_font"><?php the_title(); ?></p>
          </div>
<?php if(ot_get_option('show_breadcrumbs') !== ''){ ?>
          <div class="pull-right">
            <p class="white about_p_font margin_top_contact_bg_text"><?php get_breadcrumb(); ?></p>
          </div>
          <?php }?>

        </div>
    </div>
  </div>

<?php } elseif(is_home() || is_archive() || is_author() || is_category() || is_tag()){?>

  <div class="col-md-12 col-sm-12 col-xs-12 padding_zero contact_bg" style="background: url(<?php echo ot_get_option('header_background_image'); ?>);">
    <div class="contact_layer"></div>
    <div class="container">
        <div class="col-md-12 col-sm-12 col-xs-12 contact_margin_top">
          <div class="pull-left">
            <p class="contact_font">Blog</p>
          </div>

          <?php if(ot_get_option('show_breadcrumbs') !== ''){ ?>
          <div class="pull-right">
            <p class="white about_p_font margin_top_contact_bg_text"><?php get_breadcrumb(); ?></p>
          </div>
          <?php }?>

        </div>
    </div>
  </div>

<?php } elseif(is_search()){?>

  <div class="col-md-12 col-sm-12 col-xs-12 padding_zero contact_bg" style="background: url(<?php echo ot_get_option('header_background_image'); ?>);">
    <div class="contact_layer"></div>
    <div class="container">
        <div class="col-md-12 col-sm-12 col-xs-12 contact_margin_top">
          <div class="pull-left">
            <p class="contact_font">Search</p>
          </div>

          <?php if(ot_get_option('show_breadcrumbs') !== ''){ ?>
          <div class="pull-right">
            <p class="white about_p_font margin_top_contact_bg_text"><?php get_breadcrumb(); ?></p>
          </div>
          <?php }?>

        </div>
    </div>
  </div>

<?php } elseif(is_404()){?>

  <div class="col-md-12 col-sm-12 col-xs-12 padding_zero contact_bg" style="background: url(<?php echo ot_get_option('header_background_image'); ?>);">
    <div class="contact_layer"></div>
    <div class="container">
        <div class="col-md-12 col-sm-12 col-xs-12 contact_margin_top">
          <div class="pull-left">
            <p class="contact_font">404</p>
          </div>

          <?php if(ot_get_option('show_breadcrumbs') !== ''){ ?>
          <div class="pull-right">
            <p class="white about_p_font margin_top_contact_bg_text"><?php get_breadcrumb(); ?></p>
          </div>
          <?php }?>

        </div>
    </div>
  </div>

<?php } ?>

<!-- Breadcrumb Over -->