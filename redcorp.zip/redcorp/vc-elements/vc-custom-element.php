<?php


/*
 * Register custom param types for Visual Composer shortcodes
 */
if ( ! class_exists( 'PT_VC_Custom_Param_Types' ) ) {
	class PT_VC_Custom_Param_Types {
		// FontAwesome icons for brochure box shortcode
		private $fa_click_icons_brochure_box;
		// Initialization of the param types
		public function __construct() {
			$this->fa_click_icons_brochure_box = array(
			 'fa-file-o',
			 'fa-file-pdf-o',
			 'fa-file-word-o',
			 'fa-file-text-o',
			 'fa-file-image-o',
			 'fa-file-powerpoint-o',
			 'fa-file-excel-o',
			 'fa-file-audio-o',
			 'fa-file-video-o',
			 'fa-file-archive-o',
			 'fa-file-code-o',
			 'fa-save',
			 'fa-download',
			 'fa-print',
			 'fa-info-circle',
			 'fa-question-circle',
			 'fa-cog',
			 'fa-link',
			);
			// Register custom param types
			vc_add_shortcode_param( 'upload_file', array( $this, 'upload_file' ) );
			vc_add_shortcode_param( 'select_fa_icon_bb', array( $this, 'select_fa_icon_bb' ) );
			vc_add_shortcode_param( 'input_range', array( $this, 'input_range' ) );
			vc_add_shortcode_param( 'input_number', array( $this, 'input_number' ) );
			vc_add_shortcode_param( 'lined_textarea', array( $this, 'lined_textarea' ) );
		}

		// Function for registering the upload_file custom param type
		function upload_file( $settings, $value ) {
			ob_start();
			?>

			<div class="select_fa_icon_bb_param_block">
				<input name="<?php echo esc_attr( $settings['param_name'] ); ?>" class="wpb_vc_param_value wpb-textinput <?php echo esc_attr( $settings['param_name'] ) . ' ' . esc_attr( $settings['type'] ); ?>_field" id="<?php echo esc_attr( $settings['param_name'] ); ?>" type="text" value="<?php echo esc_attr( $value ); ?>" />
				<input type="button" onclick="ProteusWidgetsUploader.fileUploader.openFileFrame( '<?php echo esc_attr( $settings['param_name'] ); ?>' );" class="upload-brochure-file button button-secondary" value="<?php _ex( 'Upload file', 'backend', 'vc-elements-pt' ); ?>" />
			</div>

			<?php
			return ob_get_clean();
		}


		// Function for registering the select_fa_icon_bb custom param type
		function select_fa_icon_bb( $settings, $value ) {
			ob_start();
			?>

			<div class="select_fa_icon_bb_param_block">
				<small><?php printf( __( 'Click on the icon below or manually select from the %s website', 'vc-elements-pt' ), '<a href="http://fontawesome.io/icons/" target="_blank">FontAwesome</a>' ); ?> </small>
				<input name="<?php echo esc_attr( $settings['param_name'] ); ?>" class="wpb_vc_param_value wpb-textinput js-icon-input <?php echo esc_attr( $settings['param_name'] ) . ' ' . esc_attr( $settings['type'] ); ?>_field" id="<?php echo esc_attr( $settings['param_name'] ); ?>" type="text" value="<?php echo esc_attr( $value ); ?>" />
				<br>
				<br>
			<?php
			foreach ( $this->fa_click_icons_brochure_box as $icon ) :
			?>
				<a class="js-selectable-icon  icon-widget" href="#" data-iconname="<?php echo esc_attr( $icon ); ?>"><i class="fa fa-lg <?php echo esc_attr( $icon ); ?>"></i></a>
			<?php
			endforeach;
			?>
			</div>

			<?php
			return ob_get_clean();
		}

		

		// Function for registering the input_range custom param type
		function input_range( $settings, $value ) {
			ob_start();	
			?>

			<div class="input_range_param_block">
				<input id="<?php echo esc_attr( $settings['param_name'] ); ?>" name="<?php echo esc_attr( $settings['param_name'] ); ?>" class="wpb_vc_param_value wpb-textinput <?php echo esc_attr( $settings['param_name'] ) . ' ' . esc_attr( $settings['type'] ); ?>_field" type="range" min="<?php echo esc_attr( $settings['min'] ); ?>" max="<?php echo esc_attr( $settings['max'] ); ?>" value="<?php echo esc_attr( $value ); ?>" onchange="<?php echo esc_attr( $settings['param_name'] ); ?>range()"/> 

				<h4 id="<?php echo esc_attr( $settings['param_name'] ); ?>_span">Skillbar Percent = <?php echo esc_attr( $value ); ?></h4>
				<script type="text/javascript">

					function <?php echo esc_attr( $settings['param_name'] ); ?>range() {
						    var x = document.getElementById("<?php echo esc_attr( $settings['param_name'] ); ?>");
						    document.getElementById("<?php echo esc_attr( $settings['param_name'] ); ?>_span").innerHTML = "Skillbar Percent = "+ x.value;
						}

					/*$('#<?php echo esc_attr( $settings['param_name'] ); ?>').change( function() { 	            
  					$("#<?php echo esc_attr( $settings['param_name'] ); ?>_span").html('Skillbar Percent = '+ $(this).val());
  				});*/

				</script>
					
				
			</div>

			<?php
			return ob_get_clean();
		}

		// Function for registering the input_number custom param type
		function input_number( $settings, $value ) {
			ob_start();
			?>

			<div class="input_number_param_block">
				<input name="<?php echo esc_attr( $settings['param_name'] ); ?>" class="wpb_vc_param_value wpb-textinput <?php echo esc_attr( $settings['param_name'] ) . ' ' . esc_attr( $settings['type'] ); ?>_field" type="number" min="<?php echo esc_attr( $settings['min'] ); ?>" max="<?php echo esc_attr( $settings['max'] ); ?>" value="<?php echo esc_attr( $value ); ?>" required />
			</div>

			<?php
			return ob_get_clean();
		}
		function lined_textarea( $settings, $value ) {
			$value = str_replace( ',', PHP_EOL, $value );
			ob_start();
			?>

			<textarea rows="<?php echo esc_attr( $settings['rows'] ); ?>" name="<?php echo esc_attr( $settings['param_name'] ); ?>" class="wpb_vc_param_value wpb-textarea <?php echo esc_attr( $settings['param_name'] ) . ' ' . esc_attr( $settings['type'] ); ?>"><?php echo esc_textarea( $value ); ?></textarea>

			<?php
			return ob_get_clean();
		}
	}
	new PT_VC_Custom_Param_Types;
}




require_once( get_template_directory().'/vc-elements/elements/rc-features.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-about_section_home.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-our_features.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-portfolio.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-counter.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-why_choose_us.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-our_partners.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-our_team.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-our_blog_two.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-testimonial.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-home_slider.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-about_section_aboutpage.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-case_studies.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-story_about_us.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-portfolio_page.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-get_in_touch.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-map.php' );
require_once( get_template_directory().'/vc-elements/elements/rc-contact_form.php' );
?>