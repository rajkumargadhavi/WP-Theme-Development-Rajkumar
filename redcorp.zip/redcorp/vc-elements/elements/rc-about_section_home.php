<?php

//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC About Section Home
*/
//////////////////////////////////////////////////////////////////////////////////

// Element Class 
class rcAboutSectionHome extends WPBakeryShortCode {
  
    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_about_section_home_mapping' ) );
        add_shortcode( 'rc_about_section_home', array( $this, 'rc_about_section_home_html' ) );
    }
     
    // Element Mapping
    public function rc_about_section_home_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC About Section Home', 'text-domain'),
        'base' => 'rc_about_section_home',
        'description' => __('Red Corporate About Section Home', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_about_section_home.png',            
        'params' => array( 


      
                  
                //General Setting
                array(
                    'type' => 'textfield',
                    'class' => '',
                    'heading' => __( 'Section Title', 'text-domain' ),
                    'param_name' => 'sectiontitle',
                    'value' => '<span class="span_red">A</span>bout <span class="span_red">U</span>s',
                    'description' => __( 'Section Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textarea',
                    'class' => '',
                    'heading' => __( 'Section Sub Title', 'text-domain' ),
                    'param_name' => 'sectionsubtitle',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                    'description' => __( 'Section Sub Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),

                //About Setting
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'title',
                    'value' => 'We Are An Awesome Agency',
                    'description' => __( 'Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'About Section',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Details', 'text-domain' ),
                    'param_name' => 'details',
                    'value' =>'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
                    'description' => __( 'Section Details', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'About Section',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Text', 'text-domain' ),
                    'param_name' => 'skillbar1',
                    'value' => 'Html5',
                    'description' => __( 'Skillbar Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'About Section',
                ), 
                array(
                    'type' => 'input_range',
                    'max' => '100',
                    'min' => '0',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Percent', 'text-domain' ),
                    'param_name' => 'percentskillbar1',
                    'value' => '100',
                    'description' => __( 'Skillbar Percent', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'About Section',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Text', 'text-domain' ),
                    'param_name' => 'skillbar2',
                    'value' => 'CSS3',
                    'description' => __( 'Skillbar Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'About Section',
                ), 
                array(
                    'type' => 'input_range',
                    'max' => '100',
                    'min' => '0',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Percent', 'text-domain' ),
                    'param_name' => 'percentskillbar2',
                    'value' => '95',
                    'description' => __( 'Skillbar Percent', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'About Section',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Text', 'text-domain' ),
                    'param_name' => 'skillbar3',
                    'value' => 'Jquery',
                    'description' => __( 'Skillbar Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'About Section',
                ), 
                array(
                    'type' => 'input_range',
                    'max' => '100',
                    'min' => '0',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Percent', 'text-domain' ),
                    'param_name' => 'percentskillbar3',
                    'value' => '70',
                    'description' => __( 'Skillbar Percent', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'About Section',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Text', 'text-domain' ),
                    'param_name' => 'skillbar4',
                    'value' => '',
                    'description' => __( 'Skillbar Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'About Section',
                ), 
                array(
                    'type' => 'input_range',
                    'max' => '100',
                    'min' => '0',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Percent', 'text-domain' ),
                    'param_name' => 'percentskillbar4',
                    'value' => '0',
                    'description' => __( 'Skillbar Percent', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'About Section',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Text', 'text-domain' ),
                    'param_name' => 'skillbar5',
                    'value' => '',
                    'description' => __( 'Skillbar Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'About Section',
                ), 
                array(
                    'type' => 'input_range',
                    'max' => '100',
                    'min' => '0',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Percent', 'text-domain' ),
                    'param_name' => 'percentskillbar5',
                    'value' => '0',
                    'description' => __( 'Skillbar Percent', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'About Section',
                ),
                 array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'First Title', 'text-domain' ),
                    'param_name' => 'right_title_first',
                    'value' => 'Absolutely',
                    'description' => __( 'Skillbar Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Side Text',
                ), 
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Second Title', 'text-domain' ),
                    'param_name' => 'right_title_second',
                    'value' => 'Awesome.',
                    'description' => __( 'Skillbar Percent', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Side Text',
                ),     
            )
        )
    );                                
        
    }
      
    // Element HTML
    public function rc_about_section_home_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //General Setting 
                'sectiontitle' => '<span class="span_red">A</span>bout <span class="span_red">U</span>s',
                'sectionsubtitle'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',

                //About Setting 
                'title' => 'We Are An Awesome Agency',
                'details'   => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.',
                'skillbar1'   => 'Html5',
                'percentskillbar1'   => '100',
                'skillbar2'   => 'CSS3',
                'percentskillbar2'   => '95',
                'skillbar3'   => 'Jquery',
                'percentskillbar3'   => '70',
                'skillbar4'   => '',
                'percentskillbar4'   => '',
                'skillbar5'   => '',
                'percentskillbar5'   => '',
                'right_title_first'   => 'Absolutely',
                'right_title_second'   => 'Awesome.',                
               
            ), 
            $atts
        )
    );
     
    // Fill $html var with data
    $html = '
    <div class="col-md-12 col-sm-12 col-xs-12 padding_zero about  wow fadeInUp animated" data-wow-duration="0.7s">
    <div class="container">

    '. ($sectionsubtitle =="" && $sectionsubtitle =="" ? "":'<div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
        '. ($sectiontitle =="" ? "":'<p class="title">'.$sectiontitle.'</p>') .'
        '. ($sectionsubtitle =="" ? "":'<p class="para">'.$sectionsubtitle.'</p>') .' 
        </div>') .' 

        <div class="col-md-12 col-sm-12 col-xs-12 padding_zero margin_top">
            <div class="col-md-6 col-sm-6 col-xs-12  wow fadeInLeft animated" data-wow-duration="1.7s">

            '. ($title =="" ? "":'<p class="about_title">'.$title.'</p>') .'
            '. ($details =="" ? "":'<p class="about_p">'.$details.'</p>') .'
                

                '. ($percentskillbar1 =="" || $skillbar1 =="" ? "":'<div class="skillbar margin_top clearfix " data-percent="'.$percentskillbar1.'%">
                  <div class="skillbar-title"><span>'.$skillbar1.'</span></div>
                  <div class="skillbar-bar"></div>
                  <div class="skill-bar-percent">'.$percentskillbar1.'%</div>
                </div>') .'

                '. ($percentskillbar2 =="" || $skillbar2 =="" ? "":'<div class="skillbar clearfix" data-percent="'.$percentskillbar2.'%">
                  <div class="skillbar-title"><span>'.$skillbar2.'</span></div>
                  <div class="skillbar-bar"></div>
                  <div class="skill-bar-percent">'.$percentskillbar2.'%</div>
                </div>') .'

                '. ($percentskillbar3 =="" || $skillbar3 =="" ? "":'<div class="skillbar clearfix" data-percent="'.$percentskillbar3.'%">
                  <div class="skillbar-title"><span>'.$skillbar3.'</span></div>
                  <div class="skillbar-bar"></div>
                  <div class="skill-bar-percent">'.$percentskillbar3.'%</div>
                </div>') .'

                '. ($percentskillbar4 =="" || $skillbar4 =="" ? "":'<div class="skillbar clearfix" data-percent="'.$percentskillbar4.'%">
                  <div class="skillbar-title"><span>'.$skillbar4.'</span></div>
                  <div class="skillbar-bar"></div>
                  <div class="skill-bar-percent">'.$percentskillbar4.'%</div>
                </div>') .'


                '. ($percentskillbar5 =="" || $skillbar5 =="" ? "":'<div class="skillbar clearfix" data-percent="'.$percentskillbar5.'%">
                  <div class="skillbar-title"><span>'.$skillbar5.'</span></div>
                  <div class="skillbar-bar"></div>
                  <div class="skill-bar-percent">'.$percentskillbar5.'%</div>
                </div>') .'

            </div>


        '. ($right_title_first =="" && $right_title_second =="" ? "":'<div class="col-md-6 col-sm-6 col-xs-12  wow fadeInRight animated" data-wow-duration="1.7s">
                    <div class="separator  transparent"></div>
                    <div class="q_elements_item vertical_alignment_middle horizontal_align_center grow_in grow_in_on" data-animation="no"><div class="q_elements_item_inner"><div class="q_elements_item_content q_elements_inner_2092291639 margin_top"><div class="custom_font_holder absolutely"  data-font-size="110" data-line-height="110"><div>
                    '. ($right_title_first =="" ? "":'<p>'.$right_title_first.'</p>') .'
                    
                    </div></div></div></div></div>
                    <div class="custom_font_holder awesome" data-font-size="103" data-line-height="103"><div>
        '. ($right_title_second =="" ? "":'<p>'.$right_title_second.'</p>') .'

                    </div></div>
                        
                    </div>') .'

        </div>
    </div>
 </div>';      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcAboutSectionHome();   

//////////////////////////////////////////////////////////////////////////////////
?>
