<?php

//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Portfolio Page
*/
//////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcPortfolioPage extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_portfolio_page_mapping' ) );
        add_shortcode( 'rc_portfolio_page', array( $this, 'rc_portfolio_page_html' ) );
    }
     
    // Element Mapping
    public function rc_portfolio_page_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC Portfolio Page', 'text-domain'),
        'base' => 'rc_portfolio_page',
        'description' => __('Red Corporate Portfolio', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_portfolio_page.png',            
        'params' => array( 

              
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_portfolio_page_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(     
               
            ), 
            $atts
        )
    );
    ob_start();?>
    

   <div class="col-md-12 col-sm-12 col-xs-12 padding_zero bg about">
 <div class="container">
        <div class="row">
        <div align="center ">

        <?php

$taxonomy = 'technology';
$terms = get_terms($taxonomy); // Get all terms of a taxonomy 

 //  echo get_term_link($term->slug, $taxonomy); this code for link of category of portfolio
if ( $terms && !is_wp_error( $terms ) ) :

 foreach ($terms as $term) {
        $tslugs_arr[] = "".$term->name;
    }
    $terms_slug_str = join( " ", $tslugs_arr);
    ?>

 <script type="text/javascript">
  $(function () {
    
    var filterList = {
    
      init: function () {
      
        // MixItUp plugin
        // http://mixitup.io
        $('#portfoliolist').mixItUp({
          selectors: {
            target: '.portfolio',
            filter: '.filter' 
          },
          load: {
            filter: '<?php echo $terms_slug_str; ?>'  
          }     
        });               
      
      }

    };
    
    // Run the show!
    filterList.init();
    
    
  }); 
  </script>

          <button class="btn btn-default filter-button" data-filter="all">All</button>
            
        <?php foreach ( $terms as $term ) { ?>
            <button class="btn btn-default filter-button" data-filter="<?php echo $term->slug; ?>"><?php echo $term->name; ?></button>
        <?php } ?>
    
<?php endif;?>

        </div>
        <br/>

<?php

$args = array( 'post_type' => 'portfolio','posts_per_page' => -1,'orderby' => 'modified');          

$myposts = get_posts( $args );

foreach ( $myposts as $post ) : setup_postdata( $post ); ?>


            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-12 filter all <?php $arr = wp_get_post_terms($post->ID, 'technology', array("fields" => "slugs")); echo implode(" ",$arr); ?>">
                <div class="container1">
                    <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?>" class="img_width image">
                    <div class="overlay1">
                      <div class="title"><a href="<?php echo get_permalink($post->ID); ?>" class="white"><?php echo get_the_title($post->ID); ?></a></div>
                      <div class="text"><?php $arr = wp_get_post_terms($post->ID, 'technology', array("fields" => "names")); echo implode(" / ",$arr); ?></div>
                    </div>
                  </div>
            </div>
            <?php
  endforeach; 
wp_reset_postdata();?>

        </div>
    </div>
</div>     
     
   <?php
    $output = ob_get_contents();
    ob_get_clean();
      return $output;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcPortfolioPage();   

//////////////////////////////////////////////////////////////////////////////////
?>

