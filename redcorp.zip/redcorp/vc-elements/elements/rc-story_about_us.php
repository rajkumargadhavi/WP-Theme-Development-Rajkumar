<?php

//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Story About Us
*/
//////////////////////////////////////////////////////////////////////////////////

// Element Class 
class rcStoryAboutUs extends WPBakeryShortCode {
  
    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_story_about_us_mapping' ) );
        add_shortcode( 'rc_story_about_us', array( $this, 'rc_story_about_us_html' ) );
    }
     
    // Element Mapping
    public function rc_story_about_us_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC Story About Us', 'text-domain'),
        'base' => 'rc_story_about_us',
        'description' => __('Red Corporate Story About Us', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_story_about_us.png',            
        'params' => array( 


      

                //About Setting
                array(
                  'type' => 'attach_image',
                  'class' => '',
                  'heading' => __( 'Upload Image', "text-domain" ),
                  'param_name' => 'attach_img',
                  'value' => '',
                  'description' => __( 'Upload Background Image', 'text-domain' ),
                  'group' => 'General',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'title',
                    'value' => 'STORY ABOUT US',
                    'description' => __( 'Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Details', 'text-domain' ),
                    'param_name' => 'details',
                    'value' =>"There are many variations of passages of Lorem Ipsum available, but the majoity have suffered alteration in some form, by injected hum or randomis words which don't look even slightly believable. If you are going to u passage of Lorem Ipsum, you need to be sure there isn't anything embarrassi hidden in the middle of text. All the Lorem Ipsum generators on the Internet ten to repeat predefined chunks as necessary, making generator",
                    'description' => __( 'Section Details', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Text', 'text-domain' ),
                    'param_name' => 'skillbar1',
                    'value' => 'Html5',
                    'description' => __( 'Skillbar Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ), 
                array(
                    'type' => 'input_range',
                    'max' => '100',
                    'min' => '0',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Percent', 'text-domain' ),
                    'param_name' => 'percentskillbar1',
                    'value' => '100',
                    'description' => __( 'Skillbar Percent', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Text', 'text-domain' ),
                    'param_name' => 'skillbar2',
                    'value' => 'CSS3',
                    'description' => __( 'Skillbar Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ), 
                array(
                    'type' => 'input_range',
                    'max' => '100',
                    'min' => '0',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Percent', 'text-domain' ),
                    'param_name' => 'percentskillbar2',
                    'value' => '95',
                    'description' => __( 'Skillbar Percent', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Text', 'text-domain' ),
                    'param_name' => 'skillbar3',
                    'value' => 'Jquery',
                    'description' => __( 'Skillbar Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ), 
                array(
                    'type' => 'input_range',
                    'max' => '100',
                    'min' => '0',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Percent', 'text-domain' ),
                    'param_name' => 'percentskillbar3',
                    'value' => '70',
                    'description' => __( 'Skillbar Percent', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Text', 'text-domain' ),
                    'param_name' => 'skillbar4',
                    'value' => 'Wordpress',
                    'description' => __( 'Skillbar Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ), 
                array(
                    'type' => 'input_range',
                    'max' => '100',
                    'min' => '0',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Percent', 'text-domain' ),
                    'param_name' => 'percentskillbar4',
                    'value' => '60',
                    'description' => __( 'Skillbar Percent', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Text', 'text-domain' ),
                    'param_name' => 'skillbar5',
                    'value' => 'Performance',
                    'description' => __( 'Skillbar Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ), 
                array(
                    'type' => 'input_range',
                    'max' => '100',
                    'min' => '0',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Skillbar Percent', 'text-domain' ),
                    'param_name' => 'percentskillbar5',
                    'value' => '90',
                    'description' => __( 'Skillbar Percent', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                
            )
        )
    );                                
        
    }
      
    // Element HTML
    public function rc_story_about_us_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //About Setting 
                'attach_img'   => '',
                'title' => 'STORY ABOUT US',
                'details'   => "There are many variations of passages of Lorem Ipsum available, but the majoity have suffered alteration in some form, by injected hum or randomis words which don't look even slightly believable. If you are going to u passage of Lorem Ipsum, you need to be sure there isn't anything embarrassi hidden in the middle of text. All the Lorem Ipsum generators on the Internet ten to repeat predefined chunks as necessary, making generator",
                'skillbar1'   => 'Html5',
                'percentskillbar1'   => '100',
                'skillbar2'   => 'CSS3',
                'percentskillbar2'   => '95',
                'skillbar3'   => 'Jquery',
                'percentskillbar3'   => '70',
                'skillbar4'   => 'Wordpress',
                'percentskillbar4'   => '60',
                'skillbar5'   => 'Performance',
                'percentskillbar5'   => '90',               
               
            ), 
            $atts
        )
    );
     
    // Fill $html var with data
    $html = '<div class="col-md-12 col-sm-12 col-xs-12 padding_zero progress_bg" style="background: url('. ($attach_img =="" ? get_template_directory_uri().'/vc-elements/elements/images/story_about_us.jpg':wp_get_attachment_url($attach_img)) .');">
  <div class="contact_layer"></div>
      <div class="container">
            <div class="col-md-12 col-sm-12 col-xs-12 padding_zero">
                <div class="col-md-6 col-sm-6 col-xs-12 white">
                    '. ($title =="" ? "":'<h2 class=""><b>'.$title.'</b></h2>') .'

                    '. ($details =="" ? "":'<p class="about_p read_margin_top">'.$details.'</p>') .'
                </div>

  

                <div class="col-md-6 col-sm-6 col-xs-12">


                '. ($percentskillbar1 =="" || $skillbar1 =="" ? "":'<div class="skillbar margin_top clearfix " data-percent="'.$percentskillbar1.'%">
                  <div class="skillbar-title"><span>'.$skillbar1.'</span></div>
                  <div class="skillbar-bar"></div>
                  <div class="skill-bar-percent">'.$percentskillbar1.'%</div>
                </div>') .'

                '. ($percentskillbar2 =="" || $skillbar2 =="" ? "":'<div class="skillbar clearfix" data-percent="'.$percentskillbar2.'%">
                  <div class="skillbar-title"><span>'.$skillbar2.'</span></div>
                  <div class="skillbar-bar"></div>
                  <div class="skill-bar-percent">'.$percentskillbar2.'%</div>
                </div>') .'

                '. ($percentskillbar3 =="" || $skillbar3 =="" ? "":'<div class="skillbar clearfix" data-percent="'.$percentskillbar3.'%">
                  <div class="skillbar-title"><span>'.$skillbar3.'</span></div>
                  <div class="skillbar-bar"></div>
                  <div class="skill-bar-percent">'.$percentskillbar3.'%</div>
                </div>') .'

                '. ($percentskillbar4 =="" || $skillbar4 =="" ? "":'<div class="skillbar clearfix" data-percent="'.$percentskillbar4.'%">
                  <div class="skillbar-title"><span>'.$skillbar4.'</span></div>
                  <div class="skillbar-bar"></div>
                  <div class="skill-bar-percent">'.$percentskillbar4.'%</div>
                </div>') .'


                '. ($percentskillbar5 =="" || $skillbar5 =="" ? "":'<div class="skillbar clearfix" data-percent="'.$percentskillbar5.'%">
                  <div class="skillbar-title"><span>'.$skillbar5.'</span></div>
                  <div class="skillbar-bar"></div>
                  <div class="skill-bar-percent">'.$percentskillbar5.'%</div>
                </div>') .'
                
                </div>
            </div>
      </div>
  </div>';      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcStoryAboutUs();   

//////////////////////////////////////////////////////////////////////////////////
?>