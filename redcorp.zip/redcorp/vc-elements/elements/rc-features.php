<?php
//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Features
*/
 //////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcFeatures extends WPBakeryShortCode {
     
    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_features_mapping' ) );
        add_shortcode( 'rc_features', array( $this, 'rc_features_html' ) );
    }
     
    // Element Mapping
    public function rc_features_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
            'name' => __('RC Features', 'text-domain'),
            'base' => 'rc_features',
            'description' => __('Red Corporate Features Section', 'text-domain'), 
            'category' => __('Red Corporate Custom Elements', 'text-domain'),   
            'icon' => get_template_directory_uri().'/vc-elements/img/rc_features.png',            
            'params' => array(   
                  
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox1',
                    'value' => 'fa fa-eye',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'First Box',

                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlebox1',
                    'value' => 'Research',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'First Box',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textbox1',
                    'value' =>'Lorem ipsum dolor sit amet, consectetuer adip iscing elit, enean commodo.',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'First Box',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Button Text', 'text-domain' ),
                    'param_name' => 'buttontextbox1',
                    'value' => 'Read More',
                    'description' => __( 'Box Button Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'First Box',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Button Link', 'text-domain' ),
                    'param_name' => 'buttonlinkbox1',
                    'value' => '#',
                    'description' => __( 'Box Button Link', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'First Box',
                ),

                //Second Box 
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox2',
                    'value' => 'fa fa-cloud',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Second Box',

                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlebox2',
                    'value' => 'Design',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Second Box',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textbox2',
                    'value' =>'Lorem ipsum dolor sit amet, consectetuer adip iscing elit, enean commodo.',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Second Box',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Button Text', 'text-domain' ),
                    'param_name' => 'buttontextbox2',
                    'value' => 'Read More',
                    'description' => __( 'Box Button Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Second Box',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Button Link', 'text-domain' ),
                    'param_name' => 'buttonlinkbox2',
                    'value' => '#',
                    'description' => __( 'Box Button Link', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Second Box',
                ),

                //Third Box

                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox3',
                    'value' => 'fa fa-tasks',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Third Box',

                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlebox3',
                    'value' => 'Development',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Third Box',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textbox3',
                    'value' =>'Lorem ipsum dolor sit amet, consectetuer adip iscing elit, enean commodo.',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Third Box',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Button Text', 'text-domain' ),
                    'param_name' => 'buttontextbox3',
                    'value' => 'Read More',
                    'description' => __( 'Box Button Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Third Box',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Button Link', 'text-domain' ),
                    'param_name' => 'buttonlinkbox3',
                    'value' => '#',
                    'description' => __( 'Box Button Link', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Third Box',
                ),                   
                     
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_features_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //First Box
                'icon_fontawesomebox1' => 'fa fa-eye',
                'titlebox1'   => 'Research',
                'textbox1' => 'Lorem ipsum dolor sit amet, consectetuer adip iscing elit, enean commodo.',
                'buttontextbox1' => 'Read More',
                'buttonlinkbox1' => '#',
                //Second Box
                'icon_fontawesomebox2' => 'fa fa-cloud',
                'titlebox2'   => 'Design',
                'textbox2' => 'Lorem ipsum dolor sit amet, consectetuer adip iscing elit, enean commodo.',
                'buttontextbox2' => 'Read More',
                'buttonlinkbox2' => '#',
                //Third Box
                'icon_fontawesomebox3' => 'fa fa-tasks',
                'titlebox3'   => 'Development',
                'textbox3' => 'Lorem ipsum dolor sit amet, consectetuer adip iscing elit, enean commodo.',
                'buttontextbox3' => 'Read More',
                'buttonlinkbox3' => '#',
            ), 
            $atts
        )
    );
     
    // Fill $html var with data
    $html = '
    <div class="col-md-12 col-sm-12 col-xs-12 padding_zero feature_position wow fadeInUp animated" data-wow-duration="0.7s">
      <div class="container">
          <div class="col-md-4 col-sm-4 col-xs-12 padding_zero feature_bg text-center">
              <i class="'.$icon_fontawesomebox1.' feature_icon" aria-hidden="true"></i>
              <p class="feature_title">'.$titlebox1.'</p>
              <p class="feature_p">'.$textbox1.'</p>
              <a href="'.$buttonlinkbox1.'" class="feature_btn">'.$buttontextbox1.'</a>
          </div>

          <div class="col-md-4 col-sm-4 col-xs-12 padding_zero feature_bg text-center">
              <i class="'.$icon_fontawesomebox2.' feature_icon" aria-hidden="true"></i>
              <p class="feature_title">'.$titlebox2.'</p>
              <p class="feature_p">'.$textbox2.'</p>
              <a href="'.$buttonlinkbox2.'" class="feature_btn">'.$buttontextbox2.'</a>
          </div>

<div class="col-md-4 col-sm-4 col-xs-12 padding_zero feature_bg text-center">
              <i class="'.$icon_fontawesomebox3.' feature_icon" aria-hidden="true"></i>
              <p class="feature_title">'.$titlebox3.'</p>
              <p class="feature_p">'.$textbox3.'</p>
              <a href="'.$buttonlinkbox3.'" class="feature_btn">'.$buttontextbox3.'</a>
          </div>

      </div>
  </div>';      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcFeatures();   

//////////////////////////////////////////////////////////////////////////////////



?>