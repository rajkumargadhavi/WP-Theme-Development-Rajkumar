<?php

//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Our Features
*/
//////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcOurFeatures extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_our_features_mapping' ) );
        add_shortcode( 'rc_our_features', array( $this, 'rc_our_features_html' ) );
    }
     
    // Element Mapping
    public function rc_our_features_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC Our Features', 'text-domain'),
        'base' => 'rc_our_features',
        'description' => __('Red Corporate Our Features', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_our_features.png',            
        'params' => array( 

               
                  
                //General Setting
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Title', 'text-domain' ),
                    'param_name' => 'sectiontitle',
                    'value' => '<span class="span_red">O</span>ur <span class="span_red">F</span>eatures',
                    'description' => __( 'Section Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Sub Title', 'text-domain' ),
                    'param_name' => 'sectionsubtitle',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                    'description' => __( 'Section Sub Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                  'type' => 'attach_image',
                  'class' => '',
                  'heading' => __( 'Upload Image', "text-domain" ),
                  'param_name' => 'attach_img',
                  'value' => '',
                  'description' => __( 'Upload Our Feature Image', 'text-domain' ),
                  'group' => 'General',
                ),

                //Left Features Section Setting
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox1',
                    'value' => 'fa fa-paint-brush',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Left Features',

                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlefeature1',
                    'value' => 'Unlimited Colors',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Left Features',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textfeature1',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Left Features',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox2',
                    'value' => 'fa fa-cog',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Left Features',

                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlefeature2',
                    'value' => 'Unbelievable options',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Left Features',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textfeature2',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Left Features',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox3',
                    'value' => 'fa fa-leaf',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Left Features',

                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlefeature3',
                    'value' => 'Clean Design',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Left Features',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textfeature3',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Left Features',
                ),

                //Right Features Section Setting
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox4',
                    'value' => 'fa fa-compress',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Features',

                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlefeature4',
                    'value' => 'Responsive layout',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Features',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textfeature4',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Features',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox5',
                    'value' => 'fa fa-rocket',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Features',

                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlefeature5',
                    'value' => 'Easy to Customise',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Features',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textfeature5',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Features',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox6',
                    'value' => 'fa fa-check',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Features',

                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlefeature6',
                    'value' => 'User Friendly',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Features',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textfeature6',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Features',
                ),

                
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_our_features_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //General Setting 
                'sectiontitle' => '<span class="span_red">O</span>ur <span class="span_red">F</span>eatures',
                'sectionsubtitle'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'attach_img'   => '',

                //Left Features Section Setting
                'icon_fontawesomebox1' => 'fa fa-paint-brush',
                'titlefeature1'   => 'Unlimited Colors',
                'textfeature1'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',

                'icon_fontawesomebox2' => 'fa fa-cog',
                'titlefeature2'   => 'Unbelievable options',
                'textfeature2'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',

                'icon_fontawesomebox3' => 'fa fa-leaf',
                'titlefeature3'   => 'Clean Design',
                'textfeature3'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',

                //Right Features Section Setting
                'icon_fontawesomebox4' => 'fa fa-compress',
                'titlefeature4'   => 'Responsive layout',
                'textfeature4'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',

                'icon_fontawesomebox5' => 'fa fa-rocket',
                'titlefeature5'   => 'Easy to Customise',
                'textfeature5'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',

                'icon_fontawesomebox6' => 'fa fa-check',
                'titlefeature6'   => 'User Friendly',
                'textfeature6'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',
                                
               
            ), 
            $atts
        )
    );
     
    // Fill $html var with data
    $html = '<div class="col-md-12 col-sm-12 col-xs-12 padding_zero service  wow fadeInUp animated" data-wow-duration="0.7s">
      <div class="container">

        '. ($sectionsubtitle =="" && $sectionsubtitle =="" ? "":'<div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
        '. ($sectiontitle =="" ? "":'<p class="title">'.$sectiontitle.'</p>') .'
        '. ($sectionsubtitle =="" ? "":'<p class="para">'.$sectionsubtitle.'</p>') .' 
        </div>') .' 


          <div class="col-md-12 col-sm-12 col-xs-12 padding_zero margin_top">
              <div class="col-md-4 col-sm-4 col-xs-12  wow fadeInLeft animated" data-wow-duration="1.7s">
                  <div class="corp_icon">
                      <div class="icon">
                          <i class="'.$icon_fontawesomebox1.'" aria-hidden="true"></i>
                      </div>
                      <div class="content">
                          <p class="title">'.$titlefeature1.'</p>
                          <p class="para">'.$textfeature1.'</p> 
                      </div>
                  </div>

                  <div class="corp_icon">
                      <div class="icon">
                          <i class="'.$icon_fontawesomebox2.'" aria-hidden="true"></i>
                      </div>
                      <div class="content">
                          <p class="title">'.$titlefeature2.'</p>
                          <p class="para">'.$textfeature2.'</p>
                      </div>
                  </div>

                  <div class="corp_icon">
                      <div class="icon">
                          <i class="'.$icon_fontawesomebox3.'" aria-hidden="true"></i>
                      </div>
                      <div class="content">
                          <p class="title">'.$titlefeature3.'</p>
                          <p class="para">'.$textfeature3.'</p>
                      </div>
                  </div>
              </div>

               <div class="col-md-4 col-sm-4 col-xs-12  wow fadeInUp animated" data-wow-duration="1.7s">
                  <img src="'. ($attach_img =="" ? get_template_directory_uri().'/vc-elements/elements/images/business-woman.png':wp_get_attachment_url($attach_img)) .'" class="service_img">

              </div>

               <div class="col-md-4 col-sm-4 col-xs-12 margin_top_media  wow fadeInRight animated" data-wow-duration="1.7s">
                  <div class="corp_icon right_align">
                      <div class="icon">
                          <i class="'.$icon_fontawesomebox4.'" aria-hidden="true"></i>
                      </div>
                      <div class="content">
                          <p class="title">'.$titlefeature4.'</p>
                          <p class="para">'.$textfeature4.'</p>
                      </div>
                  </div>

                  <div class="corp_icon right_align">
                      <div class="icon">
                          <i class="'.$icon_fontawesomebox5.'" aria-hidden="true"></i>
                      </div>
                      <div class="content">
                          <p class="title">'.$titlefeature5.'</p>
                          <p class="para">'.$textfeature5.'</p>
                      </div>
                  </div>

                  <div class="corp_icon right_align">
                      <div class="icon">
                          <i class="'.$icon_fontawesomebox6.'" aria-hidden="true"></i>
                      </div>
                      <div class="content">
                          <p class="title">'.$titlefeature6.'</p>
                          <p class="para">'.$textfeature6.'</p>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>';      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcOurFeatures();   

//////////////////////////////////////////////////////////////////////////////////
?>

