<?php

//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Blog Two
*/
//////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcBlogTwo extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_blog_two_mapping' ) );
        add_shortcode( 'rc_blog_two', array( $this, 'rc_blog_two_html' ) );
    }
     
    // Element Mapping
    public function rc_blog_two_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC Blog Two', 'text-domain'),
        'base' => 'rc_blog_two',
        'description' => __('Red Corporate Blog Two', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_blog_two.png',            
        'params' => array( 

               
                  
                //General Setting
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Title', 'text-domain' ),
                    'param_name' => 'sectiontitle',
                    'value' => '<span class="span_red">O</span>ur <span class="span_red">B</span>log',
                    'description' => __( 'Section Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Sub Title', 'text-domain' ),
                    'param_name' => 'sectionsubtitle',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                    'description' => __( 'Section Sub Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     => __('Number of Portfolio Show'),
                    'param_name'  => 'selectednumber',
                    'admin_label' => true,
                    'value'       => array(
                                          '2'   => '2',
                                          '4'   => '4',
                                          '6'   => '6',
                                          '8'   => '8'
                                        ), //value
                    "std"         => " ",
                    'description' => __('number of portfolio show in page select from dropdown.'),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_blog_two_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //General Setting 
                'sectiontitle' => '<span class="span_red">O</span>ur <span class="span_red">B</span>log',
                'sectionsubtitle'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'selectednumber' => '2',
                
               
            ), 
            $atts
        )
    );
    
    

    // Fill $html var with data
    $html =  '<div class="col-md-12 col-sm-12 col-xs-12 padding_zero service about  wow fadeInUp animated" data-wow-duration="0.7s">
      <div class="container">

          '. ($sectionsubtitle =="" && $sectionsubtitle =="" ? "":'<div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
        '. ($sectiontitle =="" ? "":'<p class="title">'.$sectiontitle.'</p>') .'
        '. ($sectionsubtitle =="" ? "":'<p class="para">'.$sectionsubtitle.'</p>') .' 
        </div>').'<div class="col-md-12 col-sm-12 col-xs-12 padding_zero margin_top">'?>

        <?php
          $args = array('post_type' => 'post','orderby' => 'post_date','posts_per_page' => $selectednumber);

          $post_query = new WP_Query($args);

          if($post_query->have_posts() ) {

          while($post_query->have_posts() ) {

          $post_query->the_post(); 
          
          ?>

  <?php 
     $html .='<div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="blog_bg">
                      <img src="'. wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ) .'" class="img_width">
                      <div class="post-info">
                          <div class="post-info-left">
                              <span class="post-author">
                                <i class="fa fa-calendar icofont" aria-hidden="true"></i> '.get_the_date( 'd' ).' '.get_the_date( 'M' ).'
                              </span>                           
                              <span class="post-author">
                                <i class="fa fa-user icofont" aria-hidden="true"></i>'.get_the_author($post->ID).'
                              </span>
                              <span class="post-author">
                                <i class="fa fa-folder icofont" aria-hidden="true"></i>
                                <ul class="post-categories">
                                  <li><a href="'.get_category_link(get_cat_ID(get_the_category($post->ID)[0]->name)).'" rel="category tag" class="black">'.get_the_category($post->ID)[0]->name.'</a></li>
                                </ul>                           
                              </span>
                              <span class="post-author">
                                <i class="fa fa-comment icofont" aria-hidden="true"></i>'.get_comments_number().'                          
                              </span>
                          </div>
                        </div>

                        <p class="blog_title"><a href="'.get_permalink($post->ID).'" class="black ">'.get_the_title().'</a></p>

                        <p class="blog_p">'.get_the_excerpt().'</p>

                        <a href="'.get_permalink($post->ID).'" class="feature_btn">Read More</a>
                  </div>
              </div>'?>
              <?php 
            } } 
            $html .= '</div> </div> </div>'; 
 

                  
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcBlogTwo();   

//////////////////////////////////////////////////////////////////////////////////
?>