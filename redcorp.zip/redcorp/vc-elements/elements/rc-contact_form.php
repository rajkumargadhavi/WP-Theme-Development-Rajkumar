<?php
//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Contact Form
*/
 //////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcContactForm extends WPBakeryShortCode {
     
    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_contact_form_mapping' ) );
        add_shortcode( 'rc_contact_form', array( $this, 'rc_contact_form_html' ) );
    }
     
    // Element Mapping
    public function rc_contact_form_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(

            'name' => __('RC Contact Form', 'text-domain'),
            'base' => 'rc_contact_form',
            'description' => __('Red Corporate Contact Form', 'text-domain'), 
            'category' => __('Red Corporate Custom Elements', 'text-domain'),   
            'icon' => get_template_directory_uri().'/vc-elements/img/rc_contact_form.png',            
            'params' => array(   

                //General
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'title',
                    'value' =>'Send a Message',
                    'description' => __( 'Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    "type" => "textarea_html",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __( "Paste Your Contact Form7 Short Code", "text-domain" ),
                    "param_name" => "content", // Important: Only one textarea_html param per content element allowed and it should have "content" as a "param_name"
                    "value" => __( "", "text-domain" ),
                    "description" => __( "Contact Form7 Short Code", "text-domain" ),
                    "admin_label" => false,
                    "weight" => 0,
                    "group" => 'General',
                 )
                  
                     
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_contact_form_html( $atts,$content = null ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //First Box
                'title' => 'Send a Message',         
            ), 
            $atts
        )
    );
   $content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content

   ob_start();?>
    
<div class="col-md-12 col-sm-12 col-xs-12 service">
            <div class="">
        <p class="contact_title"><?php echo $title; ?></p>
        <?php echo do_shortcode($content); ?>
</div>
</div>
     
   <?php
    $output = ob_get_contents();
    ob_get_clean();
      return $output;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcContactForm();   

//////////////////////////////////////////////////////////////////////////////////

?>



