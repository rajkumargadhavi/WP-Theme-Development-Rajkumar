<?php
//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Case Studies
*/
 //////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcCaseStudies extends WPBakeryShortCode {
     
    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_casestudies_mapping' ) );
        add_shortcode( 'rc_casestudies', array( $this, 'rc_casestudies_html' ) );
    }
     
    // Element Mapping
    public function rc_casestudies_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
            'name' => __('RC Case Studies', 'text-domain'),
            'base' => 'rc_casestudies',
            'description' => __('Red Corporate Case Studies Section', 'text-domain'), 
            'category' => __('Red Corporate Custom Elements', 'text-domain'),   
            'icon' => get_template_directory_uri().'/vc-elements/img/rc_casestudies.png',            
            'params' => array(   
                  
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox1',
                    'value' => 'fa fa-book',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'First Box',
                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlebox1',
                    'value' => 'CASE STUDIES',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'First Box',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textbox1',
                    'value' =>'There are many variations of passages of Lorem Ipsum available, but the majority.',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'First Box',
                ),
               

                //Second Box 
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox2',
                    'value' => 'fa fa-list-ul',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Second Box',
                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlebox2',
                    'value' => 'ABOUT US',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Second Box',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textbox2',
                    'value' =>'There are many variations of passages of Lorem Ipsum available, but the majority.',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Second Box',
                ),
               

                //Third Box

                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox3',
                    'value' => 'fa fa-openid',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Third Box',
                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlebox3',
                    'value' => 'WORDPRESS',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Third Box',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textbox3',
                    'value' =>'There are many variations of passages of Lorem Ipsum available, but the majority.',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Third Box',
                ),
                               
                     
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_casestudies_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //First Box
                'icon_fontawesomebox1' => 'fa fa-book',
                'titlebox1'            => 'CASE STUDIES',
                'textbox1'             => 'There are many variations of passages of Lorem Ipsum available, but the majority.',
                //Second Box
                'icon_fontawesomebox2' => 'fa fa-list-ul',
                'titlebox2'            => 'ABOUT US',
                'textbox2'             => 'There are many variations of passages of Lorem Ipsum available, but the majority.',
                //Third Box
                'icon_fontawesomebox3' => 'fa fa-openid',
                'titlebox3'            => 'WORDPRESS',
                'textbox3'             => 'There are many variations of passages of Lorem Ipsum available, but the majority.',
            ), 
            $atts
        )
    );
     
    // Fill $html var with data
    $html = '<div class="col-md-12 col-sm-12 col-xs-12 padding_zero about bg ">
      <div class="container">
         <div class="col-md-12 col-sm-12 col-xs-12 padding_zero text-center">

            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="about_icon_i">
                    <i class="'.$icon_fontawesomebox1.'" aria-hidden="true"></i>
                </div>

                <p class="contact_title">'.$titlebox1.'</p>
                <p class="about_p">'.$textbox1.'</p>
            </div>  

            <div class="col-md-4 col-sm-4 col-xs-12 margin_top_media">
                <div class="about_icon_i">
                    <i class="'.$icon_fontawesomebox2.'" aria-hidden="true"></i>
                </div>

                <p class="contact_title">'.$titlebox2.'</p>
                <p class="about_p">'.$textbox2.'</p>
            </div>  

            <div class="col-md-4 col-sm-4 col-xs-12 margin_top_media">  
                <div class="about_icon_i">
                    <i class="'.$icon_fontawesomebox2.'" aria-hidden="true"></i>
                </div>

                <p class="contact_title">'.$titlebox3.'</p>
                <p class="about_p">'.$textbox3.'</p>
            </div>  

         </div>
      </div>
  </div>';      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcCaseStudies();   

//////////////////////////////////////////////////////////////////////////////////

?>

 