<?php

//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Counter
*/
//////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcCounter extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_counter_mapping' ) );
        add_shortcode( 'rc_counter', array( $this, 'rc_counter_html' ) );
    }
     
    // Element Mapping
    public function rc_counter_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC Counter', 'text-domain'),
        'base' => 'rc_counter',
        'description' => __('Red Corporate Counter', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_counter.png',            
        'params' => array( 

               
                  
                //General Setting
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Title', 'text-domain' ),
                    'param_name' => 'sectiontitle',
                    'value' => 'WORK IN FIGURE',
                    'description' => __( 'Section Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Sub Title', 'text-domain' ),
                    'param_name' => 'sectionsubtitle',
                    'value' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                    'description' => __( 'Section Sub Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),               
                array(
                  'type' => 'attach_image',
                  'class' => '',
                  'heading' => __( 'Upload Image', "text-domain" ),
                  'param_name' => 'attach_img',
                  'value' => '',
                  'description' => __( 'Upload Background Image', 'text-domain' ),
                  'group' => 'General',
                ),

                //Counter

                array(
                    'type' => 'input_number',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Counter1 Number', 'text-domain' ),
                    'param_name' => 'count1number',
                    'value' => '200',
                    'description' => __( 'Counter1 Number', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Counter',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Counter1 Value', 'text-domain' ),
                    'param_name' => 'count1value',
                    'value' => 'EMPLOYEE',
                    'description' => __( 'Counter1 Value', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Counter',
                ),  
                array(
                    'type' => 'input_number',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Counter2 Number', 'text-domain' ),
                    'param_name' => 'count2number',
                    'value' => '150',
                    'description' => __( 'Counter2 Number', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Counter',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Counter2 Value', 'text-domain' ),
                    'param_name' => 'count2value',
                    'value' => 'SATISFACTION',
                    'description' => __( 'Counter2 Value', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Counter',
                ),  
                array(
                    'type' => 'input_number',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Counter3 Number', 'text-domain' ),
                    'param_name' => 'count3number',
                    'value' => '1000',
                    'description' => __( 'Counter3 Number', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Counter',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Counter3 Value', 'text-domain' ),
                    'param_name' => 'count3value',
                    'value' => 'COFFEE CUPS',
                    'description' => __( 'Counter3 Value', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Counter',
                ),  
                array(
                    'type' => 'input_number',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Counter4 Number', 'text-domain' ),
                    'param_name' => 'count4number',
                    'value' => '250',
                    'description' => __( 'Counter4 Number', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Counter',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Counter4 Value', 'text-domain' ),
                    'param_name' => 'count4value',
                    'value' => 'RATINGS',
                    'description' => __( 'Counter4 Value', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Counter',
                ),  
                
                
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_counter_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //General Setting 
                'sectiontitle' => 'WORK IN FIGURE',
                'sectionsubtitle'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'attach_img'   => '',

                //Counter
                'count1number' => '200',
                'count1value'   => 'EMPLOYEE',
                'count2number' => '150',
                'count2value'   => 'SATISFACTION',
                'count3number' => '1000',
                'count3value'   => 'COFFEE CUPS',
                'count4number' => '250',
                'count4value'   => 'RATINGS',
                  
               
            ), 
            $atts
        )
    );
     

          


    // Fill $html var with data
    $html = '<div class="col-md-12 col-sm-12 col-xs-12 padding_zero parallax_bg text-center  wow fadeInUp animated" data-wow-duration="0.7s" style="background:url('. ($attach_img =="" ? get_template_directory_uri().'/vc-elements/elements/images/statics-section-ng.jpg':wp_get_attachment_url($attach_img)) .') 50% 50% fixed;">
      <div class="container">

         '. ($sectionsubtitle =="" && $sectionsubtitle =="" ? "":'<div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
        '. ($sectiontitle =="" ? "":'<p class="title">'.$sectiontitle.'</p>') .'
        '. ($sectionsubtitle =="" ? "":'<p class="para">'.$sectionsubtitle.'</p>') .' 
        </div>') .' 


          <div class="col-md-12 col-sm-12 col-xs-12 margin_top">
              <div class="col-md-3 col-sm-3 col-xs-12 ">
                 <div class="counter_bg">
                    <div class="content">
                      <span class="counter counter_font">'.$count1number.'</span>  
                      <span class="text-uppercase counter_para">'.$count1value.'</span>
                    </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-3 col-xs-12 margin_top_media">
                 <div class="counter_bg">
                    <div class="content">
                      <span class="counter counter_font">'.$count2number.'</span>  
                      <span class="text-uppercase counter_para">'.$count2value.'</span>
                    </div>
                 </div>
              </div>
              <div class="col-md-3 col-sm-3 col-xs-12 margin_top_media">
                 <div class="counter_bg">
                    <div class="content">
                      <span class="counter counter_font">'.$count3number.'</span>  
                      <span class="text-uppercase counter_para">'.$count3value.'</span>
                    </div>
                 </div>
              </div>
              <div class="col-md-3 col-sm-3 col-xs-12 margin_top_media">
                 <div class="counter_bg">
                    <div class="content">
                      <span class="counter counter_font">'.$count4number.'</span>  
                      <span class="text-uppercase counter_para">'.$count4value.'</span>
                    </div>
                 </div>
              </div>
          </div>
      </div>
  </div>';      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcCounter();   

//////////////////////////////////////////////////////////////////////////////////
?>

  