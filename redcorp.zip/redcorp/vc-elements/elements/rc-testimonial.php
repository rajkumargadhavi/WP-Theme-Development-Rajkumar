<?php

//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Testimonial
*/
//////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcTestimonial extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_testimonial_mapping' ) );
        add_shortcode( 'rc_testimonial', array( $this, 'rc_testimonial_html' ) );
    }
     
    // Element Mapping
    public function rc_testimonial_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC Testimonial', 'text-domain'),
        'base' => 'rc_testimonial',
        'description' => __('Red Corporate Testimonial', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_testimonial.png',            
        'params' => array( 

               
                  
                //General Setting
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Title', 'text-domain' ),
                    'param_name' => 'sectiontitle',
                    'value' => '<span class="span_red">T</span>estimonial',
                    'description' => __( 'Section Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Sub Title', 'text-domain' ),
                    'param_name' => 'sectionsubtitle',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                    'description' => __( 'Section Sub Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_testimonial_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //General Setting 
                'sectiontitle' => '<span class="span_red">T</span>estimonial',
                'sectionsubtitle'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            ), 
            $atts
        )
    );
    
    

    // Fill $html var with data
    $html =  '  <div class="col-md-12 col-sm-12 col-xs-12 padding_zero about">
      <div class="container">

          '. ($sectionsubtitle =="" && $sectionsubtitle =="" ? "":'<div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
        '. ($sectiontitle =="" ? "":'<p class="title">'.$sectiontitle.'</p>') .'
        '. ($sectionsubtitle =="" ? "":'<p class="para">'.$sectionsubtitle.'</p>') .' 
        </div>').'<div class="col-md-12 col-sm-12 col-xs-12 padding_zero margin_top"> <div class="col-md-12 col-sm-12 col-xs-12 margin_top">
            <div id="testimonial-slider" class="owl-carousel">'?>

        <?php
          $args = array('post_type' => 'testilider');

          $post_query = new WP_Query($args);

          if($post_query->have_posts() ) {

          while($post_query->have_posts() ) {

          $post_query->the_post(); 
          
          ?>

  <?php 

    $html .='<div class="testimonial">
                    <div class="pic">
                        <img src="'. wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ) .'">
                    </div>
                    <p class="description">'.get_the_content().'</p>
                    <h3 class="title">'.get_the_title().'</h3>
                    <small class="post">- '.get_the_terms(($post->ID), 'designation')[0]->name.'</small>
                </div>'?>
              <?php 
            } } 

    $html .= '</div> </div> </div> </div>'; 

    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcTestimonial();   

//////////////////////////////////////////////////////////////////////////////////
?>





        


                



              
            