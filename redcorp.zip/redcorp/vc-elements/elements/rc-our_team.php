<?php

//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Our Team
*/
//////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcOurTeam extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_our_team_mapping' ) );
        add_shortcode( 'rc_our_team', array( $this, 'rc_our_team_html' ) );
    }
     
    // Element Mapping
    public function rc_our_team_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC Our Team', 'text-domain'),
        'base' => 'rc_our_team',
        'description' => __('Red Corporate Our Team', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_our_team.png',            
        'params' => array( 
 
                  
                //General Setting
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Title', 'text-domain' ),
                    'param_name' => 'sectiontitle',
                    'value' => '<span class="span_red">O</span>ur <span class="span_red">T</span>eam ',
                    'description' => __( 'Section Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Sub Title', 'text-domain' ),
                    'param_name' => 'sectionsubtitle',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                    'description' => __( 'Section Sub Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),

                //Team Member1 Setting
                array(
                    'type' => 'attach_image',
                    'class' => '',
                    'heading' => __( 'Upload Image', "text-domain" ),
                    'param_name' => 'profilemember1',
                    'value' => '',
                    'description' => __( 'Upload Team Member Image', 'text-domain' ),
                    'group' => 'Tab1',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Select Social Icon', 'text-domain' ),
                    'param_name' => 'socialicon1member1',
                    'value' => 'fa fa-facebook',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab1',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Add Social Link Url', 'text-domain' ),
                    'param_name' => 'sociallink1member1',
                    'value' => '#',
                    'description' => __( 'Add Social Link Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab1',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Select Social Icon', 'text-domain' ),
                    'param_name' => 'socialicon2member1',
                    'value' => 'fa fa-twitter',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab1',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Add Social Link Url', 'text-domain' ),
                    'param_name' => 'sociallink2member1',
                    'value' => '#',
                    'description' => __( 'Add Social Link Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab1',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Select Social Icon', 'text-domain' ),
                    'param_name' => 'socialicon3member1',
                    'value' => 'fa fa-google-plus',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab1',
                ),  
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Add Social Link Url', 'text-domain' ),
                    'param_name' => 'sociallink3member1',
                    'value' => '#',
                    'description' => __( 'Add Social Link Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab1',
                ),  
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Name', 'text-domain' ),
                    'param_name' => 'namemember1',
                    'value' => 'Jon Smith',
                    'description' => __( 'Name', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab1',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Designation', 'text-domain' ),
                    'param_name' => 'designationmember1',
                    'value' => 'Designer',
                    'description' => __( 'Designation', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab1',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Short Details', 'text-domain' ),
                    'param_name' => 'detailsmember1',
                    'value' =>'There are many variatio passages of Lorem Ipsum available, but the majority suffered alteration in some by injected.',
                    'description' => __( 'Short Details', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab1',
                ),


                //Team Member2 Setting
                array(
                    'type' => 'attach_image',
                    'class' => '',
                    'heading' => __( 'Upload Image', "text-domain" ),
                    'param_name' => 'profilemember2',
                    'value' => '',
                    'description' => __( 'Upload Team Member Image', 'text-domain' ),
                    'group' => 'Tab2',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Select Social Icon', 'text-domain' ),
                    'param_name' => 'socialicon1member2',
                    'value' => 'fa fa-facebook',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab2',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Add Social Link Url', 'text-domain' ),
                    'param_name' => 'sociallink1member2',
                    'value' => '#',
                    'description' => __( 'Add Social Link Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab2',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Select Social Icon', 'text-domain' ),
                    'param_name' => 'socialicon2member2',
                    'value' => 'fa fa-twitter',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab2',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Add Social Link Url', 'text-domain' ),
                    'param_name' => 'sociallink2member2',
                    'value' => '#',
                    'description' => __( 'Add Social Link Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab2',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Select Social Icon', 'text-domain' ),
                    'param_name' => 'socialicon3member2',
                    'value' => 'fa fa-google-plus',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab2',
                ),  
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Add Social Link Url', 'text-domain' ),
                    'param_name' => 'sociallink3member2',
                    'value' => '#',
                    'description' => __( 'Add Social Link Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab2',
                ),  
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Name', 'text-domain' ),
                    'param_name' => 'namemember2',
                    'value' => 'Jon Smith',
                    'description' => __( 'Name', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab2',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Designation', 'text-domain' ),
                    'param_name' => 'designationmember2',
                    'value' => 'Designer',
                    'description' => __( 'Designation', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab2',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Short Details', 'text-domain' ),
                    'param_name' => 'detailsmember2',
                    'value' =>'There are many variatio passages of Lorem Ipsum available, but the majority suffered alteration in some by injected.',
                    'description' => __( 'Short Details', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab2',
                ),


                //Team Member3 Setting
                array(
                    'type' => 'attach_image',
                    'class' => '',
                    'heading' => __( 'Upload Image', "text-domain" ),
                    'param_name' => 'profilemember3',
                    'value' => '',
                    'description' => __( 'Upload Team Member Image', 'text-domain' ),
                    'group' => 'Tab3',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Select Social Icon', 'text-domain' ),
                    'param_name' => 'socialicon1member3',
                    'value' => 'fa fa-facebook',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab3',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Add Social Link Url', 'text-domain' ),
                    'param_name' => 'sociallink1member3',
                    'value' => '#',
                    'description' => __( 'Add Social Link Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab3',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Select Social Icon', 'text-domain' ),
                    'param_name' => 'socialicon2member3',
                    'value' => 'fa fa-twitter',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab3',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Add Social Link Url', 'text-domain' ),
                    'param_name' => 'sociallink2member3',
                    'value' => '#',
                    'description' => __( 'Add Social Link Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab3',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Select Social Icon', 'text-domain' ),
                    'param_name' => 'socialicon3member3',
                    'value' => 'fa fa-google-plus',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab3',
                ),  
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Add Social Link Url', 'text-domain' ),
                    'param_name' => 'sociallink3member3',
                    'value' => '#',
                    'description' => __( 'Add Social Link Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab3',
                ),  
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Name', 'text-domain' ),
                    'param_name' => 'namemember3',
                    'value' => 'Angle Smith',
                    'description' => __( 'Name', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab3',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Designation', 'text-domain' ),
                    'param_name' => 'designationmember3',
                    'value' => 'Designer',
                    'description' => __( 'Designation', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab3',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Short Details', 'text-domain' ),
                    'param_name' => 'detailsmember3',
                    'value' =>'There are many variatio passages of Lorem Ipsum available, but the majority suffered alteration in some by injected.',
                    'description' => __( 'Short Details', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab3',
                ),


                //Team Member4 Setting
                array(
                    'type' => 'attach_image',
                    'class' => '',
                    'heading' => __( 'Upload Image', "text-domain" ),
                    'param_name' => 'profilemember4',
                    'value' => '',
                    'description' => __( 'Upload Team Member Image', 'text-domain' ),
                    'group' => 'Tab4',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Select Social Icon', 'text-domain' ),
                    'param_name' => 'socialicon1member4',
                    'value' => 'fa fa-facebook',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab4',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Add Social Link Url', 'text-domain' ),
                    'param_name' => 'sociallink1member4',
                    'value' => '#',
                    'description' => __( 'Add Social Link Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab4',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Select Social Icon', 'text-domain' ),
                    'param_name' => 'socialicon2member4',
                    'value' => 'fa fa-twitter',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab4',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Add Social Link Url', 'text-domain' ),
                    'param_name' => 'sociallink2member4',
                    'value' => '#',
                    'description' => __( 'Add Social Link Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab4',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Select Social Icon', 'text-domain' ),
                    'param_name' => 'socialicon3member4',
                    'value' => 'fa fa-google-plus',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab4',
                ),  
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Add Social Link Url', 'text-domain' ),
                    'param_name' => 'sociallink3member4',
                    'value' => '#',
                    'description' => __( 'Add Social Link Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab4',
                ),  
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Name', 'text-domain' ),
                    'param_name' => 'namemember4',
                    'value' => 'Lora Smith',
                    'description' => __( 'Name', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab4',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Designation', 'text-domain' ),
                    'param_name' => 'designationmember4',
                    'value' => 'Designer',
                    'description' => __( 'Designation', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab4',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Short Details', 'text-domain' ),
                    'param_name' => 'detailsmember4',
                    'value' =>'There are many variatio passages of Lorem Ipsum available, but the majority suffered alteration in some by injected.',
                    'description' => __( 'Short Details', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Tab4',
                ),
            )
        )
    );                                    
}
     
     
    // Element HTML
    public function rc_our_team_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //General Setting 
                'sectiontitle'      => '<span class="span_red">O</span>ur <span class="span_red">T</span>eam',
                'sectionsubtitle'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                

                //Tab 1
                'profilemember1'       => '',
                'socialicon1member1'   => 'fa fa-facebook',
                'sociallink1member1'   => '#',
                'socialicon2member1'   => 'fa fa-twitter',
                'sociallink2member1'   => '#',
                'socialicon3member1'   => 'fa fa-google-plus',
                'sociallink3member1'   => '#',
                'namemember1'          => 'Jon Smith',
                'designationmember1'   => 'Designer',
                'detailsmember1'       => 'There are many variatio passages of Lorem Ipsum available, but the majority suffered alteration in some by injected.',

                //Tab 2
                'profilemember2'       => '',
                'socialicon1member2'   => 'fa fa-facebook',
                'sociallink1member2'   => '#',
                'socialicon2member2'   => 'fa fa-twitter',
                'sociallink2member2'   => '#',
                'socialicon3member2'   => 'fa fa-google-plus',
                'sociallink3member2'   => '#',
                'namemember2'          => 'Jon Smith',
                'designationmember2'   => 'Designer',
                'detailsmember2'       => 'There are many variatio passages of Lorem Ipsum available, but the majority suffered alteration in some by injected.',

                //Tab 3
                'profilemember3'       => '',
                'socialicon1member3'   => 'fa fa-facebook',
                'sociallink1member3'   => '#',
                'socialicon2member3'   => 'fa fa-twitter',
                'sociallink2member3'   => '#',
                'socialicon3member3'   => 'fa fa-google-plus',
                'sociallink3member3'   => '#',
                'namemember3'          => 'Angle Smith',
                'designationmember3'   => 'Designer',
                'detailsmember3'       => 'There are many variatio passages of Lorem Ipsum available, but the majority suffered alteration in some by injected.',

                //Tab 4
                'profilemember4'       => '',
                'socialicon1member4'   => 'fa fa-facebook',
                'sociallink1member4'   => '#',
                'socialicon2member4'   => 'fa fa-twitter',
                'sociallink2member4'   => '#',
                'socialicon3member4'   => 'fa fa-google-plus',
                'sociallink3member4'   => '#',
                'namemember4'          => 'Lora Smith',
                'designationmember4'   => 'Designer',
                'detailsmember4'       => 'There are many variatio passages of Lorem Ipsum available, but the majority suffered alteration in some by injected.',  
            ), 
            $atts
        )
    );
    

    // Fill $html var with data
    $html = '<div class="col-md-12 col-sm-12 col-xs-12 padding_zero team_padding  wow fadeInUp animated" data-wow-duration="0.7s">
      <div class="container">
          '. ($sectionsubtitle =="" && $sectionsubtitle =="" ? "":'<div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
        '. ($sectiontitle =="" ? "":'<p class="title">'.$sectiontitle.'</p>') .'
        '. ($sectionsubtitle =="" ? "":'<p class="para">'.$sectionsubtitle.'</p>') .' 
        </div>') .' 

          <div class="col-md-12 col-sm-12 col-xs-12 margin_top padding_zero team">
              <div class="container">
                  <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="container2">
                      <img src="'. ($profilemember1 =="" ? get_template_directory_uri().'/vc-elements/elements/images/team1.png':wp_get_attachment_url($profilemember1)) .'"  class="image">

                      <div class="t-content">
                          <h5>'.$namemember1.'</h5>
                          <p style="color:#737373">'.$designationmember1.'</p>
                      </div>
                      <div class="overlay text-center">
                          <div class="overlay_padding">
                              <div class="icon">
                                 <div class="t-bg"><a class="white" href="'.$sociallink1member1.'"><i class="'.$socialicon1member1.'" aria-hidden="true"></i></a></div>
                                  
                                 <div class="t-bg"><a class="white" href="'.$sociallink2member1.'"><i class="'.$socialicon2member1.'" aria-hidden="true"></i></a></div>
                                  
                                 <div class="t-bg"><a class="white" href="'.$sociallink3member1.'"><i class="'.$socialicon2member1.'" aria-hidden="true"></i></a></div>
                              </div>
                              <p class="">'.$detailsmember1.'</p>
                              <hr>
                              <div class="content">
                                  <h3><a>'.$namemember1.'</a></h3>
                                  <p>'.$designationmember1.'</p>
                              </div>
                            </div>
                      </div> 
                  </div>
                  </div>


                  <div class="col-md-3 col-sm-6 col-xs-12 margin_top_media">
                  <div class="container2">
                      <img src="'. ($profilemember2 =="" ? get_template_directory_uri().'/vc-elements/elements/images/team2.png':wp_get_attachment_url($profilemember2)) .'"  class="image">

                      <div class="t-content">
                        <h5>'.$namemember2.'</h5>
                        <p style="color:#737373">'.$designationmember2.'</p>
                      </div>

                      <div class="overlay text-center">
                          <div class="overlay_padding">
                              <div class="icon">
                                 <div class="t-bg"><a class="white" href="'.$sociallink1member2.'"><i class="'.$socialicon1member2.'" aria-hidden="true"></i></a></div>
                                  
                                 <div class="t-bg"><a class="white" href="'.$sociallink2member2.'"><i class="'.$socialicon2member2.'" aria-hidden="true"></i></a></div>
                                  
                                 <div class="t-bg"><a class="white" href="'.$sociallink3member2.'"><i class="'.$socialicon3member2.'" aria-hidden="true"></i></a></div>
                              </div>
                              <p class="">'.$detailsmember2.'</p>
                              <hr>
                              <div class="content">
                                  <h3><a>'.$namemember2.'</a></h3>
                                  <p>'.$designationmember2.'</p>
                              </div>
                            </div>
                      </div> 
                      </div>
                  </div>

                  <div class="col-md-3 col-sm-6 col-xs-12 margin_top_media margin_top_media1">
                  <div class="container2">
                      <img src="'. ($profilemember3 =="" ? get_template_directory_uri().'/vc-elements/elements/images/team3.png':wp_get_attachment_url($profilemember3)) .'"  class="image">

                      <div class="t-content">
                        <h5>'.$namemember3.'</h5>
                        <p style="color:#737373">'.$designationmember3.'</p>
                      </div>

                      <div class="overlay text-center">
                          <div class="overlay_padding">
                              <div class="icon">
                                 <div class="t-bg"><a class="" href="'.$sociallink1member3.'"><i class="'.$socialicon1member3.'" aria-hidden="true"></i></a></div>
                                  
                                 <div class="t-bg"><a class="" href="'.$sociallink2member3.'"><i class="'.$socialicon2member3.'" aria-hidden="true"></i></a></div>
                                  
                                 <div class="t-bg"><a class="" href="'.$sociallink3member3.'"><i class="'.$socialicon3member3.'" aria-hidden="true"></i></a></div>
                              </div>
                              <p class="">'.$detailsmember3.'</p>
                              <hr>
                              <div class="content">
                                  <h3><a>'.$namemember3.'</a></h3>
                                  <p>'.$designationmember3.'</p>
                              </div>
                            </div>
                      </div>
                    </div> 
                  </div>

                  <div class="col-md-3 col-sm-6 col-xs-12 margin_top_media margin_top_media1">
                  <div class="container2">
                      <img src="'. ($profilemember4 =="" ? get_template_directory_uri().'/vc-elements/elements/images/team3.png':wp_get_attachment_url($profilemember4)) .'" class="image">

                      <div class="t-content">
                        <h5>'.$namemember4.'</h5>
                        <p style="color:#737373">'.$designationmember4.'</p>
                      </div>

                      <div class="overlay text-center">
                          <div class="overlay_padding">
                              <div class="icon">
                                 <div class="t-bg"><a class="" href="'.$sociallink1member4.'"><i class="'.$socialicon1member4.'" aria-hidden="true"></i></a></div>
                                  
                                 <div class="t-bg"><a class="" href="'.$sociallink2member4.'"><i class="'.$socialicon2member4.'" aria-hidden="true"></i></a></div>
                                  
                                 <div class="t-bg"><a class="" href="'.$sociallink3member4.'"><i class="'.$socialicon3member4.'" aria-hidden="true"></i></a></div>
                              </div>
                              <p class="">'.$detailsmember4.'</p>
                              <hr>
                              <div class="content">
                                  <h3><a>'.$namemember4.'</a></h3>
                                  <p>'.$designationmember4.'</p>
                              </div>
                            </div>
                      </div> 
                  </div>
                  </div>
              </div>
          </div>
      </div>
  </div>';      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcOurTeam();   

//////////////////////////////////////////////////////////////////////////////////
?>


  