<?php

//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Why Choose Us
*/
//////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcWhyChooseUs extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_why_choose_us_mapping' ) );
        add_shortcode( 'rc_why_choose_us', array( $this, 'rc_why_choose_us_html' ) );
    }
     
    // Element Mapping
    public function rc_why_choose_us_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC Why Choose Us', 'text-domain'),
        'base' => 'rc_why_choose_us',
        'description' => __('Red Corporate Why Choose Us', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_why_choose_us.png',            
        'params' => array( 

               
                  
                //General Setting
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Title', 'text-domain' ),
                    'param_name' => 'sectiontitle',
                    'value' => '<span class="span_red">W</span>hy <span class="span_red">C</span>hoose <span class="span_red">U</span>s',
                    'description' => __( 'Section Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Sub Title', 'text-domain' ),
                    'param_name' => 'sectionsubtitle',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                    'description' => __( 'Section Sub Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                  'type' => 'attach_image',
                  'class' => '',
                  'heading' => __( 'Upload Image', "text-domain" ),
                  'param_name' => 'attach_img',
                  'value' => '',
                  'description' => __( 'Upload Our Feature Image', 'text-domain' ),
                  'group' => 'General',
                ),


                //Right Side Section Setting
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox4',
                    'value' => 'fa fa-hand-peace-o',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Side',

                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlefeature4',
                    'value' => 'Reliable Agency',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Side',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textfeature4',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Side',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox5',
                    'value' => 'fa fa-users',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Side',

                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlefeature5',
                    'value' => 'We Are Expert',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Side',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textfeature5',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Side',
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox6',
                    'value' => 'fa fa-signal',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Side',

                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlefeature6',
                    'value' => 'Finance Consulting',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Side',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textfeature6',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Right Side',
                ),

                
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_why_choose_us_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //General Setting 
                'sectiontitle' => '<span class="span_red">W</span>hy <span class="span_red">C</span>hoose <span class="span_red">U</span>s',
                'sectionsubtitle'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'attach_img'   => '',

                //Right Side Section Setting
                'icon_fontawesomebox4' => 'fa fa-hand-peace-o',
                'titlefeature4'   => 'Reliable Agency',
                'textfeature4'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',

                'icon_fontawesomebox5' => 'fa fa-users',
                'titlefeature5'   => 'We Are Expert',
                'textfeature5'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',

                'icon_fontawesomebox6' => 'fa fa-signal',
                'titlefeature6'   => 'Finance Consulting',
                'textfeature6'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis',
                                
               
            ), 
            $atts
        )
    );
     
    // Fill $html var with data
    $html = '<div class="col-md-12 col-sm-12 col-xs-12 padding_zero about  wow fadeInUp animated" data-wow-duration="0.7s">
      <div class="container">
        '. ($sectionsubtitle =="" && $sectionsubtitle =="" ? "":'<div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
        '. ($sectiontitle =="" ? "":'<p class="title">'.$sectiontitle.'</p>') .'
        '. ($sectionsubtitle =="" ? "":'<p class="para">'.$sectionsubtitle.'</p>') .' 
        </div>') .' 

          <div class="col-md-12 col-sm-12 col-xs-12 padding_zero margin_top" style="background: url('. ($attach_img =="" ? get_template_directory_uri().'/vc-elements/elements/images/why-we-are-bg.jpg':wp_get_attachment_url($attach_img)) .');">
             <div class="col-md-offset-6 col-md-6 col-sm-12 col-xs-12  wow fadeInRight animated" data-wow-duration="1.7s">
              <div class=" corpo_icon_box red margin_top1">
                      <div class="icon">
                          <i class="'.$icon_fontawesomebox4.'" aria-hidden="true"></i>
                      </div>
                      <div class="content">
                          <p class="title">'.$titlefeature4.'</p>
                          <p class="para">'.$textfeature4.'</p> 
                      </div>
                  </div>

                  <div class=" corpo_icon_box red">
                      <div class="icon">
                          <i class="'.$icon_fontawesomebox5.'" aria-hidden="true"></i>
                      </div>
                      <div class="content">
                          <p class="title">'.$titlefeature5.'</p>
                          <p class="para">'.$textfeature5.'</p> 
                      </div>
                  </div>

                  <div class=" corpo_icon_box red">
                      <div class="icon">
                          <i class="'.$icon_fontawesomebox6.'" aria-hidden="true"></i>
                      </div>
                      <div class="content">
                          <p class="title">'.$titlefeature6.'</p>
                          <p class="para">'.$textfeature6.'</p> 
                      </div>
                  </div>
                </div>
          </div>
      </div>
  </div>';      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcWhyChooseUs();   

//////////////////////////////////////////////////////////////////////////////////
?>

  