<?php

//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Home Slider
*/
//////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcHomeSlider extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_home_slider_mapping' ) );
        add_shortcode( 'rc_home_slider', array( $this, 'rc_home_slider_html' ) );
    }
     
    // Element Mapping
    public function rc_home_slider_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC Home Slider', 'text-domain'),
        'base' => 'rc_home_slider',
        'description' => __('Red Corporate Home Slider', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_home_slider.png',            
        'params' => array( 

               
                  
                //General Setting
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Slider Title 1', 'text-domain' ),
                    'param_name' => 'slidertitle1',
                    'value' => 'WE ARE THE CORP',
                    'description' => __( 'Slider Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Slider Title 2', 'text-domain' ),
                    'param_name' => 'slidertitle2',
                    'value' => 'FOR FINANCIAL EXPERTS',
                    'description' => __( 'Slider Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Slider Text', 'text-domain' ),
                    'param_name' => 'slidersubtitle',
                    'value' =>'Quickly promote inexpensive e-commerce with excellent meta-services. Appropriately reinvent cross-unit human',
                    'description' => __( 'Slider Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Button Text', 'text-domain' ),
                    'param_name' => 'buttontext',
                    'value' => 'View More',
                    'description' => __( 'Button Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Button Url', 'text-domain' ),
                    'param_name' => 'buttonurl',
                    'value' => '#',
                    'description' => __( 'Button Url', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'attach_image',
                    'class' => '',
                    'heading' => __( 'Upload Image', "text-domain" ),
                    'param_name' => 'sliderimg1',
                    'value' => '',
                    'description' => __( 'Upload Slider Image', 'text-domain' ),
                    'group' => 'Images',
                ),
                array(
                    'type' => 'attach_image',
                    'class' => '',
                    'heading' => __( 'Upload Image', "text-domain" ),
                    'param_name' => 'sliderimg2',
                    'value' => '',
                    'description' => __( 'Upload Slider Image', 'text-domain' ),
                    'group' => 'Images',
                ),
                array(
                    'type' => 'attach_image',
                    'class' => '',
                    'heading' => __( 'Upload Image', "text-domain" ),
                    'param_name' => 'sliderimg3',
                    'value' => '',
                    'description' => __( 'Upload Slider Image', 'text-domain' ),
                    'group' => 'Images',
                ),
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_home_slider_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //General Setting 
                'slidertitle1'   => 'WE ARE THE CORP',
                'slidertitle2'   => 'FOR FINANCIAL EXPERTS',
                'slidersubtitle' => 'Quickly promote inexpensive e-commerce with excellent meta-services. Appropriately reinvent cross-unit human',
                'buttontext'     => 'View More',
                'buttonurl'      => '#',
                'sliderimg1'     => '',
                'sliderimg2'     => '',
                'sliderimg3'     => '',
                              
               
            ), 
            $atts
        )
    );
    
    

    // Fill $html var with data
    $html =  '<div class="col-md-12 col-sm-12 col-xs-12 padding_zero">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">

    <div class="carousel-inner">

      <div class="item active">
        <img src="'.($sliderimg1 =="" ? get_template_directory_uri().'/vc-elements/elements/images/slider1.jpg':wp_get_attachment_url($sliderimg1)).'" alt="Slider 1">
      </div>

      <div class="item">
        <img src="'.($sliderimg2 =="" ? get_template_directory_uri().'/vc-elements/elements/images/slider2.jpg':wp_get_attachment_url($sliderimg2)).'" alt="Slider 2">
      </div>
    
      <div class="item">
        <img src="'.($sliderimg3 =="" ? get_template_directory_uri().'/vc-elements/elements/images/slider3.jpg':wp_get_attachment_url($sliderimg3)).'" alt="Slider 3">
      </div> 

    </div>

    <div class="col-md-12 col-sm-12 col-xs-12 header_text_position">
      <div class="container">
          <p class="header_text_letter_space">'.$slidertitle1.'</p>
          <p class="header_title">'.$slidertitle2.'</p>
          <p class="header_p">'.$slidersubtitle.'</p>

          <p class="header_p_media"><a href="'.$buttonurl.'" class="header_btn btn-skew dt-btn">'.$buttontext.'</a></p>
      </div>
    </div>

    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
 </div>' ;      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcHomeSlider();   

//////////////////////////////////////////////////////////////////////////////////
?>

