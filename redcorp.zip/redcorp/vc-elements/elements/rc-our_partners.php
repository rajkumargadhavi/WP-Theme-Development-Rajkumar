<?php 

//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Our Partners
*/
//////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcOurPartners extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_our_partners_mapping' ) );
        add_shortcode( 'rc_our_partners', array( $this, 'rc_our_partners_html' ) );
    }
     
    // Element Mapping
    public function rc_our_partners_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC Our Partners', 'text-domain'),
        'base' => 'rc_our_partners',
        'description' => __('Red Corporate Our Partners', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_our_partners.png',            
        'params' => array( 

               
                  
                //General Setting               
                array(
                  'type' => 'attach_image',
                  'class' => '',
                  'heading' => __( 'Background Image', "text-domain" ),
                  'param_name' => 'attach_img',
                  'value' => '',
                  'description' => __( 'Upload Background Image', 'text-domain' ),
                  'group' => 'General',
                ),

                //Partners Section Setting
                array(
                  'type' => 'attach_image',
                  'class' => '',
                  'heading' => __( 'Upload Partner Image', "text-domain" ),
                  'param_name' => 'partner_img1',
                  'value' => '',
                  'description' => __( 'Upload Partner Image', 'text-domain' ),
                  'group' => 'Partners',
                ),
                array(
                  'type' => 'attach_image',
                  'class' => '',
                  'heading' => __( 'Upload Partner Image', "text-domain" ),
                  'param_name' => 'partner_img2',
                  'value' => '',
                  'description' => __( 'Upload Partner Image', 'text-domain' ),
                  'group' => 'Partners',
                ),
                array(
                  'type' => 'attach_image',
                  'class' => '',
                  'heading' => __( 'Upload Partner Image', "text-domain" ),
                  'param_name' => 'partner_img3',
                  'value' => '',
                  'description' => __( 'Upload Partner Image', 'text-domain' ),
                  'group' => 'Partners',
                ),
                array(
                  'type' => 'attach_image',
                  'class' => '',
                  'heading' => __( 'Upload Partner Image', "text-domain" ),
                  'param_name' => 'partner_img4',
                  'value' => '',
                  'description' => __( 'Upload Partner Image', 'text-domain' ),
                  'group' => 'Partners',
                ),
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_our_partners_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //General Setting 
                'attach_img'   => '',

                //Partners Section Setting
                'partner_img1'   => '',
                'partner_img2'   => '',
                'partner_img3'   => '',
                'partner_img4'   => '',
                
            ), 
            $atts
        )
    );
     
    // Fill $html var with data
    $html = '  <div class="col-md-12 col-sm-12 col-xs-12 padding_zero client_bg text-center  wow fadeInUp animated" style="background: url('. ($attach_img =="" ? get_template_directory_uri().'/vc-elements/elements/images/our-clients-bg.jpg':wp_get_attachment_url($attach_img)) .');" data-wow-duration="0.7s">
      <div class="container">
          <div class="col-md-3 col-sm-3 col-xs-12">
              <img src="'. ($partner_img1 =="" ? get_template_directory_uri().'/vc-elements/elements/images/1-1.png':wp_get_attachment_url($partner_img1)) .'" class="client_logo">
          </div>

          <div class="col-md-3 col-sm-3 col-xs-12 margin_top_media">
              <img src="'. ($partner_img2 =="" ? get_template_directory_uri().'/vc-elements/elements/images/2-1.png':wp_get_attachment_url($partner_img2)) .'" class="client_logo">
          </div>

          <div class="col-md-3 col-sm-3 col-xs-12 margin_top_media">
              <img src="'. ($partner_img3 =="" ? get_template_directory_uri().'/vc-elements/elements/images/3.png':wp_get_attachment_url($partner_img3)) .'" class="client_logo">
          </div>

          <div class="col-md-3 col-sm-3 col-xs-12 margin_top_media">
              <img src="'. ($partner_img4 =="" ? get_template_directory_uri().'/vc-elements/elements/images/4.png':wp_get_attachment_url($partner_img4)) .'" class="client_logo">
          </div>
      </div>
  </div>';      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcOurPartners();   

//////////////////////////////////////////////////////////////////////////////////
?>

  

