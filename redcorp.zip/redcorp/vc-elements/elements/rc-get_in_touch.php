<?php
//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC GET IN TOUCH
*/
 //////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcGetInTouch extends WPBakeryShortCode {
     
    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_get_in_touch_mapping' ) );
        add_shortcode( 'rc_get_in_touch', array( $this, 'rc_get_in_touch_html' ) );
    }
     
    // Element Mapping
    public function rc_get_in_touch_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
            'name' => __('RC Get In Touch', 'text-domain'),
            'base' => 'rc_get_in_touch',
            'description' => __('Red Corporate Get In Touch Section', 'text-domain'), 
            'category' => __('Red Corporate Custom Elements', 'text-domain'),   
            'icon' => get_template_directory_uri().'/vc-elements/img/rc_get_in_touch.png',            
            'params' => array(   

                //General
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Title', 'text-domain' ),
                    'param_name' => 'sectiontitle',
                    'value' => 'GET IN TOUCH WITH US',
                    'description' => __( 'Section Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                 
                //First Box  
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox1',
                    'value' => 'fa fa-map-marker',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'First Box',
                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlebox1',
                    'value' => 'HEADQUARTER',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'First Box',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textbox1',
                    'value' =>'Ganesh Meridian, S.G. Highway, Ahmedabad',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'First Box',
                ),
               

                //Second Box 
                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox2',
                    'value' => 'fa fa-phone',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Second Box',
                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlebox2',
                    'value' => 'PHONES',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Second Box',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textbox2',
                    'value' =>'+91 123 456 7890 </br> Call 24/7 0800 123 4567',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Second Box',
                ),
               

                //Third Box

                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox3',
                    'value' => 'fa fa-envelope-o',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Third Box',
                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlebox3',
                    'value' => 'EMAIL ADDRESS',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Third Box',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textbox3',
                    'value' =>'contact@yourdomain.com </br> inquiry@yourdomain.com',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Third Box',
                ),

                //Fourth Box

                array(
                    'type' => 'iconpicker',
                    'heading' => __( 'Icon', 'text-domain' ),
                    'param_name' => 'icon_fontawesomebox4',
                    'value' => 'fa fa-comments-o',
                    'description' => __( 'Select icon from library.', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Fourth Box',
                    ),    
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Title', 'text-domain' ),
                    'param_name' => 'titlebox4',
                    'value' => 'SKYPE CHAT',
                    'description' => __( 'Box Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Fourth Box',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Text', 'text-domain' ),
                    'param_name' => 'textbox4',
                    'value' =>'cuman.creative </br> creativecumanlive.chat',
                    'description' => __( 'Box Text', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Fourth Box',
                ),
                               
                     
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_get_in_touch_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //First Box
                'sectiontitle' => 'GET IN TOUCH WITH US',

                //First Box
                'icon_fontawesomebox1' => 'fa fa-map-marker',
                'titlebox1'            => 'HEADQUARTER',
                'textbox1'             => 'Ganesh Meridian, S.G. Highway, Ahmedabad',
                //Second Box
                'icon_fontawesomebox2' => 'fa fa-phone',
                'titlebox2'            => 'PHONES',
                'textbox2'             => '+91 123 456 7890 </br> Call 24/7 0800 123 4567',
                //Third Box
                'icon_fontawesomebox3' => 'fa fa-envelope-o',
                'titlebox3'            => 'EMAIL ADDRESS',
                'textbox3'             => 'contact@yourdomain.com </br> inquiry@yourdomain.com',
                //Fourth Box
                'icon_fontawesomebox4' => 'fa fa-comments-o',
                'titlebox4'            => 'SKYPE CHAT',
                'textbox4'             => 'cuman.creative </br> creativecumanlive.chat',
            ), 
            $atts
        )
    );
     
    // Fill $html var with data
    $html = '<div class="col-md-12 col-sm-12 col-xs-12 padding_zero bg about ">
    <div class="container">
    
            <h2 class="text-center"><b>'.$sectiontitle.'</b></h2>

            <div class="col-md-12 col-sm-12 col-xs-12 padding_zero text-center">
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <i class="'.$icon_fontawesomebox1.' contact_icon_border" aria-hidden="true"></i>
                    <p class="contact_title">'.$titlebox1.'</p>
                    <p class="about_p ">'.$textbox1.'</p>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12">
                    <i class="'.$icon_fontawesomebox2.' contact_icon_border" aria-hidden="true"></i>
                    <p class="contact_title">'.$titlebox2.'</p>
                    <p class="about_p ">'.$textbox2.'</p>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12">
                    <i class="'.$icon_fontawesomebox3.' contact_icon_border" aria-hidden="true"></i>
                    <p class="contact_title">'.$titlebox3.'</p>
                    <p class="about_p ">'.$textbox3.'</p>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12">
                    <i class="'.$icon_fontawesomebox4.' contact_icon_border" aria-hidden="true"></i>
                    <p class="contact_title">'.$titlebox4.'</p>
                    <p class="about_p ">'.$textbox4.'</p>
                </div>
            </div>
    </div>
</div>';      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcGetInTouch();   

//////////////////////////////////////////////////////////////////////////////////

?>