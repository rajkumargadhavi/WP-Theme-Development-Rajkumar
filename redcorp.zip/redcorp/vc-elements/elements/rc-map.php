<?php
//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Map
*/
 //////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcMap extends WPBakeryShortCode {
     
    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_map_mapping' ) );
        add_shortcode( 'rc_map', array( $this, 'rc_map_html' ) );
    }
     
    // Element Mapping
    public function rc_map_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
            'name' => __('RC Google Map', 'text-domain'),
            'base' => 'rc_map',
            'description' => __('Red Corporate Google Map', 'text-domain'), 
            'category' => __('Red Corporate Custom Elements', 'text-domain'),   
            'icon' => get_template_directory_uri().'/vc-elements/img/rc_map.png',            
            'params' => array(   

                //General
                 array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Paste Your Google Map Here', 'text-domain' ),
                    'param_name' => 'mapbox',
                    'value' =>'<iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d193588.80258659853!2d-74.12906269315698!3d40.69985076621476!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY!5e0!3m2!1sen!2sus!4v1446647383676" width="100%" height="600" frameborder="0" style="border:0" allowfullscreen=""></iframe>',
                    'description' => __( 'Google Map', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'Map',
                ),
                  
                     
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_map_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //First Box
                'mapbox' => '<iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d193588.80258659853!2d-74.12906269315698!3d40.69985076621476!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY!5e0!3m2!1sen!2sus!4v1446647383676" width="100%" height="600" frameborder="0" style="border:0" allowfullscreen=""></iframe>',

                
            ), 
            $atts
        )
    );
     
    // Fill $html var with data
    $html = '<div class="col-md-12 col-sm-12 col-xs-12 service">

            <div class="map-wrap">
                          <div class="overlay_map" onclick="style.pointerEvents="none""></div><!-- wrap map iframe to turn off mouse scroll and turn it back on on click -->
                           '.$mapbox.'
                      </div>
            
        </div>';      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcMap();   

//////////////////////////////////////////////////////////////////////////////////

?>