
<?php
//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC About Section About Page
*/
//////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcAboutSectionAboutPage extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_about_section_aboutpage_mapping' ) );
        add_shortcode( 'rc_about_section_aboutpage', array( $this, 'rc_about_section_aboutpage_html' ) );
    }
     
    // Element Mapping
    public function rc_about_section_aboutpage_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC About Section For About Page', 'text-domain'),
        'base' => 'rc_about_section_aboutpage',
        'description' => __('Red Corporate About Section For About Page', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_about_section_aboutpage.png',            
        'params' => array( 

               
                  
                //General Setting
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Title', 'text-domain' ),
                    'param_name' => 'sectiontitle',
                    'value' => '<span class="span_red">A</span>bout <span class="span_red">U</span>s',
                    'description' => __( 'Section Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Sub Title', 'text-domain' ),
                    'param_name' => 'sectionsubtitle',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                    'description' => __( 'Section Sub Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'attach_image',
                    'class' => '',
                    'heading' => __( 'Upload Image', "text-domain" ),
                    'param_name' => 'attach_img',
                    'value' => '',
                    'description' => __( 'Upload Image', 'text-domain' ),
                    'group' => 'General',
                ),
                 array(
                    "type" => "textarea_html",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __( "Content", "text-domain" ),
                    "param_name" => "content", // Important: Only one textarea_html param per content element allowed and it should have "content" as a "param_name"
                    "value" => __( "<p class='about_p'><b>About every many variations of passages of Lorem Ipsu available majorityt have suffered Donec fermentum.</b></p><p class='about_p read_margin_top'>There are many variations of passages of Lorem Ipsum available, but th majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passag you need to be sure there isn't anything.</p>
                <ul class='read_margin_top'>
                        <li class='ul_list'>Suspendisse are many variations of passages.</li>
                        <li class='ul_list'>There are many variations of passages of LorIpsum available</li>
                        <li class='ul_list'>Movie randomised words which don't look even slightly believable.</li>
                        <li class='ul_list'>Various versions have evolved over the years, sometimes.</li>
                        <li class='ul_list'>Typography fonts are many variations of variations.</li>
                </ul>", "my-text-domain" ),
                    "description" => __( "Enter your content.", "text-domain" ),
                    "admin_label" => false,
                    "weight" => 0,
                    "group" => 'General',
                 )

            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_about_section_aboutpage_html( $atts,$content = null ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //General Setting 
                'sectiontitle' => '<span class="span_red">A</span>bout <span class="span_red">U</span>s',
                'sectionsubtitle'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'attach_img'   => '',
            ), 
            $atts
        )
    );
     
$content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content

    // Fill $html var with data
    $html = '<div class="col-md-12 col-sm-12 col-xs-12 padding_zero about">
    <div class="container">
        '. ($sectionsubtitle =="" && $sectionsubtitle =="" ? "":'<div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
        '. ($sectiontitle =="" ? "":'<p class="title">'.$sectiontitle.'</p>') .'
        '. ($sectionsubtitle =="" ? "":'<p class="para">'.$sectionsubtitle.'</p>') .' 
        </div>') .' 

        <div class="col-md-12 col-sm-12 col-xs-12 padding_zero margin_top">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <img src="'. ($attach_img =="" ? get_template_directory_uri().'/vc-elements/elements/images/aboutus.jpg':wp_get_attachment_url($attach_img)) .'" class="img_width">
            </div>

            <div class="col-md-6 col-sm-6 col-xs-12 margin_top_media">'.$content.'</div>
        </div>
    </div>
 </div>';      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcAboutSectionAboutPage();   

//////////////////////////////////////////////////////////////////////////////////
?>