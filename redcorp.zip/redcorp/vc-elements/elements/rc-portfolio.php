<?php

//////////////////////////////////////////////////////////////////////////////////
/*
Element Description: RC Portfolio Home Page
*/
//////////////////////////////////////////////////////////////////////////////////


// Element Class 
class rcPortfolio extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'rc_portfolio_mapping' ) );
        add_shortcode( 'rc_portfolio', array( $this, 'rc_portfolio_html' ) );
    }
     
    // Element Mapping
    public function rc_portfolio_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }

    // Map the block with vc_map()
    vc_map( 
  
        array(
        'name' => __('RC Portfolio Home Page', 'text-domain'),
        'base' => 'rc_portfolio',
        'description' => __('Red Corporate Portfolio For Home Page', 'text-domain'), 
        'category' => __('Red Corporate Custom Elements', 'text-domain'),   
        'icon' => get_template_directory_uri().'/vc-elements/img/rc_portfolio.png',            
        'params' => array( 

               
                  
                //General Setting
                array(
                    'type' => 'textfield',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Title', 'text-domain' ),
                    'param_name' => 'sectiontitle',
                    'value' => '<span class="span_red">O</span>ur <span class="span_red">P</span>ortfolio',
                    'description' => __( 'Section Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                    'type' => 'textarea',
                    'holder' => '',
                    'class' => '',
                    'heading' => __( 'Section Sub Title', 'text-domain' ),
                    'param_name' => 'sectionsubtitle',
                    'value' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                    'description' => __( 'Section Sub Title', 'text-domain' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => 'General',
                ),
                array(
                'type'        => 'dropdown',
                'heading'     => __('Number of Portfolio Show'),
                'param_name'  => 'selectednumber',
                'admin_label' => true,
                'value'       => array(
                                      '3'   => '3',
                                      '6'   => '6',
                                      '9' => '9',
                                      '12'  => '12'
                                    ), //value
                "std"         => " ",
                'description' => __('number of portfolio show in page select from dropdown.'),
                'admin_label' => false,
                'weight' => 0,
                'group' => 'General',
                ),
            )
        )
    );                                
        
    }
     
     
    // Element HTML
    public function rc_portfolio_html( $atts ) {
     
    // Params extraction
    extract(
       $atts= shortcode_atts(
            array(

                //General Setting 
                'sectiontitle' => '<span class="span_red">O</span>ur <span class="span_red">P</span>ortfolio',
                'sectionsubtitle'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                'selectednumber' => '3',
                
               
            ), 
            $atts
        )
    );
    
    

    // Fill $html var with data
    $html =  '<div class="col-md-12 col-sm-12 col-xs-12 padding_zero about  wow fadeInUp animated" data-wow-duration="0.7s">
      <div class="container">


        '. ($sectionsubtitle =="" && $sectionsubtitle =="" ? "":'<div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
        '. ($sectiontitle =="" ? "":'<p class="title">'.$sectiontitle.'</p>') .'
        '. ($sectionsubtitle =="" ? "":'<p class="para">'.$sectionsubtitle.'</p>') .' 
        </div>') .'<div class="col-md-12 col-sm-12 col-xs-12 padding_zero margin_top">'
        ?>
        <?php
   $args = array( "post_type" => "portfolio","posts_per_page" => $selectednumber ,"orderby" => "modified");     

   $myposts = get_posts( $args ); 

           foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
<?php 
   

     $resetData = wp_reset_postdata();

     $html .='<div class="col-md-4 col-sm-4 col-xs-12 padding_zero"><div class="container1"><img src="'. wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ) .'" class="img_width image">
                    <div class="overlay1">
                      <div class="title"><a href="'.get_permalink($post->ID).'" class="white">'.get_the_title($post->ID).'</a></div>
                      <div class="text">'.implode(" / ", wp_get_post_terms($post->ID, 'technology', array("fields" => "names"))).'</div>
                    </div>
                  </div>
              </div>'; 
  endforeach; 

$resetData.'</div></div></div>' ;      
     
    return $html;
     
    }
     
} // End Element Class
 
// Element Class Init
new rcPortfolio();   

//////////////////////////////////////////////////////////////////////////////////
?>

