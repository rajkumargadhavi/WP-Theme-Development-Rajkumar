<?php
/**
 * Template part for displaying portfolio
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package redcorp
 */

?>




<div class="col-md-12 col-sm-12 col-xs-12 padding_zero about bg">
	<div class="container">
		<div class="col-md-8 col-sm-8 col-xs-12">

		 <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
  

			<img src="<?php echo $image[0]; ?>" class="img_width">

			<p class="contact_title margin_top"><?php the_title(); ?></p>

			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<p class="about_p"><?php the_content(); ?></p>
			<?php endwhile; endif; ?>
		</div>

		<div class="col-md-4 col-sm-4 col-xs-12">
			<p class="contact_title">PORTFOLIO CATEGORY</p>

			<ul>
			<?php $technology=wp_get_post_terms($post->ID, 'technology', array("fields" => "names")); 
		for($i=0;$i<count($technology);$i++){ ?>
				<li class="ul_list"><?php echo $technology[$i] ; ?></li>

				<?php }?>
				
			</ul>
		</div>
	</div>


<div class="col-md-12 col-sm-12 col-xs-12 padding_zero service">
<div class="container">
<p class="contact_title">Recent Portfolio</p>

 <?php
   $args = array( "post_type" => "portfolio","posts_per_page" => 3 ,"orderby" => "modified");     

   $myposts = get_posts( $args ); 

           foreach ( $myposts as $post ) : setup_postdata( $post ); ?>


				<div class="col-md-4 col-sm-4 col-xs-12 padding_zero">
                  <div class="container1">
                    <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ) ; ?>" class="img_width image">
                    <div class="overlay1">
                      <div class="title"><a href="<?php echo get_permalink($post->ID); ?>" class="white"> <?php echo get_the_title($post->ID); ?> </a></div>
                      <div class="text"><?php echo implode(" / ", wp_get_post_terms($post->ID, 'technology', array("fields" => "names"))); ?></div>
                    </div>
                  </div>
              </div>
<?php
 endforeach;
 wp_reset_postdata(); ?>

           </div>
</div>
</div>

