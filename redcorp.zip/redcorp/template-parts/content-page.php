<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package redcorp
 */

?>

	<?php if ( is_home() && ! is_front_page() ) : ?>

				<h1><?php single_post_title(); ?></h1>

			<?php
			endif; ?>

	
		<?php
			the_content();

			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'redcorp' ),
				'after'  => '</div>',
			) );
		?>
	


