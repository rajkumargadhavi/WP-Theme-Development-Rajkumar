<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package redcorp
 */

?>

<div class="col-md-6 col-sm-6 col-xs-12 read_margin_bottom">
  <div class="blog_bg">
      <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?>" class="img_width">
      <div class="post-info">
          <div class="post-info-left">
              <span class="post-author">
                <i class="fa fa-calendar icofont" aria-hidden="true"></i> <?php echo get_the_date( 'd' )." ".get_the_date( 'M' ); ?>                        
              </span>                           
              <span class="post-author">
                <i class="fa fa-user icofont" aria-hidden="true"></i>
                <?php echo get_the_author($post->ID); ?>
              </span>
              <span class="post-author">
                <i class="fa fa-folder icofont" aria-hidden="true"></i>
                <ul class="post-categories">
                  <li><a href="<?php echo get_category_link(get_cat_ID(get_the_category($post->ID)[0]->name)); ?>" rel="category tag" class="black"><?php echo get_the_category($post->ID)[0]->name; ?></a></li>
                </ul>                           
              </span>
              <span class="post-author">
                <i class="fa fa-comment icofont" aria-hidden="true"></i><?php echo get_comments_number(); ?>                         
              </span>
          </div>
        </div>

        <p class="blog_title"><a href="<?php echo get_permalink($post->ID); ?>" class="black "><?php echo get_the_title(); ?></a></p>

        <p class="blog_p"><?php echo get_the_excerpt(); ?></p>

        <a href="<?php echo get_permalink($post->ID); ?>" class="feature_btn">Read More</a>
  </div>
</div>