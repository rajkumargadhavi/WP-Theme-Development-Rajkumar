<?php
/**
 * Template part for displaying single posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package redcorp
 */

?>
<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
<img src="<?php echo $image[0]; ?>" class="img_width">
     <div class="caption blog_content_padding">
            <div class="post-info">
                  <div class="post-info-left">
                      <span class="post-author">
                        <i class="fa fa-calendar icofont" aria-hidden="true"></i> <?php echo get_the_date( 'd' )." ".get_the_date( 'M' ); ?>                          
                      </span>                           
                      <span class="post-author">
                        <i class="fa fa-user icofont" aria-hidden="true"></i>
                        <?php echo get_the_author($post->ID); ?>
                      </span>
                      <span class="post-author">
                        <i class="fa fa-folder icofont" aria-hidden="true"></i>
                        <ul class="post-categories">
                          <li><a href="<?php echo get_category_link(get_cat_ID(get_the_category($post->ID)[0]->name)); ?>" rel="category tag" class="black"><?php echo get_the_category($post->ID)[0]->name; ?></a></li>
                        </ul>                           
                      </span>
                      <span class="post-author">
                        <i class="fa fa-comment icofont" aria-hidden="true"></i><?php echo get_comments_number(); ?>
                      </span>
                  </div>
                </div>

                <p class="blog_title"><?php the_title(); ?></p>

            <p class="future_p about_p1 padding_top blog_p_padding_top"><?php the_content(); ?></p>

            
    </div>




    
  


