<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package redcorp
 */

get_header(); 
	?>




	<div class="col-md-12 col-sm-12 col-xs-12 padding_zero bg blog">
	   <div class="container about">
            <div class="col-md-8 col-sm-8 col-xs-12 padding_left room_detail_padding_top">
            <?php if ( 'portfolio' == get_post_type() ) {
		 get_template_part( 'template-parts/portfolio-details', get_post_type() );
		 }
		 else
		 	{
		 		while ( have_posts() ) : the_post();
		 		get_template_part( 'template-parts/blog-single', get_post_type() ); 
		 			// the_post_navigation();

		 		?>

		 		<?php

					// If comments are open or we have at least one comment, load up the comment template.

					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;
					?>

					<?php

				endwhile; // End of the loop.

				
		 	} ?>
            </div>

 <?php if ( 'portfolio' == get_post_type() ) {

		 }
		 else
		 	{ ?>
            <div class="col-md-4 col-lg-4 col-xs-12 col-sm-4 margin_top_media  blog_padding2 ">
            <?php get_sidebar(); ?>
            </div>
            <?php
             } ?>

        </div>
	</div>	

<?php get_footer();



	
	

