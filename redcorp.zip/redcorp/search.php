<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package redcorp
 */

get_header(); ?>


	<div class="col-md-12 col-sm-12 col-xs-12 padding_zero about bg blog">
	   <div class="container">
            <div class="col-md-8 col-sm-8 col-xs-12 padding_left">


              <?php

            if ( have_posts() ) :

			/* Start the Loop */
			while ( have_posts() ) : the_post();

				/**
				 * Run the loop for the search to output the results.
				 * If you want to overload this in a child theme then include a file
				 * called content-search.php and that will be used instead.
				 */
				get_template_part( 'template-parts/content', 'search' );

			endwhile;

			?>
<div class="col-md-12 col-sm-12 col-xs-12">
			<?php post_pagination(); ?>
</div>
<?php

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif; ?>



        	</div>


            <div class="col-md-4 col-lg-4 col-xs-12 col-sm-4 margin_top_media  blog_padding2 ">
                <?php get_sidebar(); ?>
        	</div>

    </div>
</div>
	
 	
<?php
get_footer();
