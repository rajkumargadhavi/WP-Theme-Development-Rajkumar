<?php
/**
 * redcorp functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package redcorp
 */

/**
//////////////////////////////////////////////////////////////////////////////////
 * Theme Options Ref:https://www.sitepoint.com/optiontree-theme-options-ui-builder/
//////////////////////////////////////////////////////////////////////////////////
 */

/* Required: set 'ot_theme_mode' filter to true. */
add_filter( 'ot_theme_mode', '__return_true' );

/* Required: include OptionTree. */
require( trailingslashit( get_template_directory() ) . 'inc/theme-options/option-tree/ot-loader.php' );
add_filter( 'ot_show_new_layout', '__return_false' );
add_filter( 'ot_show_pages', '__return_false' );



require( trailingslashit( get_template_directory() ) . 'inc/theme-options/theme-options.php' );
require( trailingslashit( get_template_directory() ) . 'inc/theme-options/client.php' );

/**
//////////////////////////////////////////////////////////////////////////////////
 * Theme Options OVER
//////////////////////////////////////////////////////////////////////////////////
 */

/**
//////////////////////////////////////////////////////////////////////////////////
 * / Path to TGM Plugin Activation class.
//////////////////////////////////////////////////////////////////////////////////
 */
require_once (get_template_directory() . '/lib/plugin_activation/required_plugin.php'); 

/**
//////////////////////////////////////////////////////////////////////////////////
 * / Path to TGM Plugin Activation class. OVER
//////////////////////////////////////////////////////////////////////////////////
 */


/**
//////////////////////////////////////////////////////////////////////////////////
 * Visual Composer Start
//////////////////////////////////////////////////////////////////////////////////
 */
// Before VC Init
add_action( 'vc_before_init', 'vc_before_init_actions' );
 
function vc_before_init_actions() {
     
    //.. Code from other Tutorials ..//
 
    // Require new custom Element
    require_once( get_template_directory().'/vc-elements/vc-custom-element.php' ); 
     
}

/**
//////////////////////////////////////////////////////////////////////////////////
 * Visual Composer Over
//////////////////////////////////////////////////////////////////////////////////
 */

/**********************************************************************************************************************************************************/
/*
======================
IMPORT DEMO Content
======================
*/


require( trailingslashit( get_template_directory() ) . 'import/import-demo-content.php' );


/**********************************************************************************************************************************************************/

/**********************************************************************************************************************************************************/

/*

======================

update checker.

======================

*/



//Initialize the update checker.



require 'theme-updates/plugin-update-checker.php' ;



$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(

    'http://cmexpertiseinfotech.in/development/update/info.json',

    __FILE__,

    'redcorp'

);





/**********************************************************************************************************************************************************/






/**
//////////////////////////////////////////////////////////////////////////////////
 * Custom Widgets Start
//////////////////////////////////////////////////////////////////////////////////
 */
 // Require new custom Element
    require_once( get_template_directory().'/inc/widgets/recent_post_with_thumbnail_widget.php' ); 
    require_once( get_template_directory().'/inc/widgets/popular_posts.php' ); 
     
/**
//////////////////////////////////////////////////////////////////////////////////
 * Custom Widgets Over
//////////////////////////////////////////////////////////////////////////////////
 */

if ( ! function_exists( 'redcorp_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function redcorp_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on redcorp, use a find and replace
		 * to change 'redcorp' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'redcorp', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'redcorp' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'redcorp_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'redcorp_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function redcorp_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'redcorp_content_width', 640 );
}
add_action( 'after_setup_theme', 'redcorp_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function redcorp_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'redcorp' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'redcorp' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'redcorp_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function redcorp_scripts() {
	wp_enqueue_style( 'redcorp-style', get_stylesheet_uri() );

	wp_enqueue_script( 'redcorp-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'redcorp-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'redcorp_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}





/**********************************************************************************************************************************************************/

//Portfolio Start

/**********************************************************************************************************************************************************/

function portfolio_function() {
add_theme_support('post-thumbnails');
register_post_type('portfolio',
    array(
    'labels' => array(
            'name' => __( 'Portfolio' ),
            'singular_name' => __( 'Portfolio' ),
            'add_new' => __( 'Add New' ),
            'add_new_item' => __( 'Add New Portfolio' ),
            'edit' => __( 'Edit' ),
            'edit_item' => __( 'Edit Portfolio' ),
            'new_item' => __( 'New Portfolio' ),
            'view' => __( 'View Portfolio' ),
            'view_item' => __( 'View Portfolio' ),
            'search_items' => __( 'Search Portfolio' ),
            'not_found' => __( 'No Portfolio found' ),
            'not_found_in_trash' => __( 'No Portfolio found in Trash' ),
            'parent' => __( 'Parent Portfolio' ),
        ),
  'public' => true,
  'show_ui' => true,
        'exclude_from_search' => true,
        'hierarchical' => true,
        'supports' => array( 'title', 'editor', 'thumbnail' ),
        'query_var' => true
        )
  );
}
add_action('init', 'portfolio_function');









function create_portfolio_taxonomies()
{
  // Add new taxonomy, make it hierarchical (like categories)
  $labels = array(
    'name' => _x( 'Technology', 'taxonomy general name' ),
    'singular_name' => _x( 'Technology', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Technology' ),
    'popular_items' => __( 'Popular Technology' ),
    'all_items' => __( 'All Technology' ),
    'parent_item' => __( 'Parent Technology' ),
    'parent_item_colon' => __( 'Parent Technology:' ),
    'edit_item' => __( 'Edit Technology' ),
    'update_item' => __( 'Update Technology' ),
    'add_new_item' => __( 'Add New Technology' ),
    'new_item_name' => __( 'New Technology Name' ),
  );
  register_taxonomy('technology',array('portfolio'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'technology' ),
  ));
}
add_action( 'init', 'create_portfolio_taxonomies');
/**********************************************************************************************************************************************************/

//Portfolio Over

/**********************************************************************************************************************************************************/

/**********************************************************************************************************************************************************/
//Testimonial Slider

/**********************************************************************************************************************************************************/
function testilider_function() {
add_theme_support('post-thumbnails');
register_post_type('testilider',
    array(
    'labels' => array(
            'name' => __( 'Testimonial' ),
            'singular_name' => __( 'Testimonial' ),
            'add_new' => __( 'Add New' ),
            'add_new_item' => __( 'Add New Testimonial' ),
            'edit' => __( 'Edit' ),
            'edit_item' => __( 'Edit Testimonial' ),
            'new_item' => __( 'New Testimonial' ),
            'view' => __( 'View Testimonial' ),
            'view_item' => __( 'View Testimonial' ),
            'search_items' => __( 'Search Testimonial' ),
            'not_found' => __( 'No Testimonial found' ),
            'not_found_in_trash' => __( 'No Testimonial found in Trash' ),
            'parent' => __( 'Parent Testimonial' ),
        ),
  'public' => true,
  'show_ui' => true,
        'exclude_from_search' => true,
        'hierarchical' => true,
        'supports' => array( 'title', 'editor', 'thumbnail' ),
        'query_var' => true
        )
  );
}
add_action('init', 'testilider_function');


function create_testilider_taxonomies()
{
  // Add new taxonomy, make it hierarchical (like categories)
  $labels = array(
    'name' => _x( 'Designation', 'taxonomy general name' ),
    'singular_name' => _x( 'Designation', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Designation' ),
    'popular_items' => __( 'Popular Designation' ),
    'all_items' => __( 'All Designation' ),
    'parent_item' => __( 'Parent Designation' ),
    'parent_item_colon' => __( 'Parent Designation:' ),
    'edit_item' => __( 'Edit Designation' ),
    'update_item' => __( 'Update Designation' ),
    'add_new_item' => __( 'Add New Designation' ),
    'new_item_name' => __( 'New Designation Name' ),
  );
  register_taxonomy('designation',array('testilider'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'designation' ),
  ));
}
add_action( 'init', 'create_testilider_taxonomies');

/**********************************************************************************************************************************************************/
//excerpt
/**********************************************************************************************************************************************************/
function wpdocs_custom_excerpt_length( $length ) {
    return 35;
}
add_filter( 'excerpt_length', 'wpdocs_custom_excerpt_length', 999 );
function wpdocs_excerpt_more( $more ) {
    return '';
}
add_filter( 'excerpt_more', 'wpdocs_excerpt_more' );




/**********************************************************************************************************************************************************/
/*

======================
SHOW REQUIRE MESSAGE WHEN PLUGIN IS DEACTIVATED
======================
*/

// function showMessageToAdmin(){
//   include_once(ABSPATH.'wp-admin/includes/plugin.php');

//   if(!is_plugin_active('advanced-custom-fields/acf.php')){
//     echo '<div class="notice error my-acf-notice is-dismissible" >';
//     echo '<p>This theme require you to install <a href="https://wordpress.org/plugins/advanced-custom-fields/">Advanced Custom Fields</a></p>';
//     echo '</div>';
//   }
// }

// add_action('admin_notices','showMessageToAdmin');



/**********************************************************************************************************************************************************/
/*
======================
CUSTOMIZABLE COLOR APPEARANCE OPTIONS
======================
*/


// function yourtheme_customize_color($wp_customize){

//   $wp_customize->add_setting('yourtheme_link_color', array(
//         'default' => '#006ec3',
//         'transport' => 'refresh',
//     ));

//     $wp_customize->add_section('yourtheme_standard_colors', array(
//         'title' => __('Colors', 'LearningWordPress'),
//         'priority' => 30,
//     ));

//     $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'yourtheme_link_color_control', array(
//       'label' => __('Link Color', 'LearningWordPress'),
//       'section' => 'yourtheme_standard_colors',
//       'settings' => 'yourtheme_link_color',
//     ) ) );

// }
// add_action('customize_register','yourtheme_customize_color');



/**********************************************************************************************************************************************************/

/* Convert hexdec color string to rgb(a) string */
 
function hex2rgba($color, $opacity = false) {
 
    $default = 'rgb(0,0,0)';
 
    //Return default if no color provided
    if(empty($color))
          return $default; 
 
    //Sanitize $color if "#" is provided 
        if ($color[0] == '#' ) {
            $color = substr( $color, 1 );
        }
 
        //Check if color has 6 or 3 characters and get values
        if (strlen($color) == 6) {
                $hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
        } elseif ( strlen( $color ) == 3 ) {
                $hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
        } else {
                return $default;
        }
 
        //Convert hexadec to rgb
        $rgb =  array_map('hexdec', $hex);
 
        //Check if opacity is set(rgba or rgb)
        if($opacity){
            if(abs($opacity) > 1)
                $opacity = 1.0;
            $output = 'rgba('.implode(",",$rgb).','.$opacity.')';
        } else {
            $output = 'rgb('.implode(",",$rgb).')';
        }
 
        //Return rgb(a) color string
        return $output;
}

/**********************************************************************************************************************************************************/

// Output Customize CSS
function yourtheme_customize_css() { ?>

    <style type="text/css">
       
.span_color{ 
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.header_btn:hover{
border: 2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.feature_icon:hover{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.feature_btn:hover{
    border: 2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.span_red{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.team .t-content h5 {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

#cssmenu > .menu-menu-1-container > ul > li:hover > a,#cssmenu .menu-menu-1-container > ul li.active a{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
a:hover, a.active, a:focus{color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}



#cssmenu > ul > li:hover > a,#cssmenu ul li.active a{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.header_btn:hover{
    border: 2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.feature_icon:hover{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.feature_btn:hover{
    border: 2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.span_red{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

input[type=search]:focus {
    border-color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

a:hover, a.active, a:focus{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
#cssmenu > ul > li:hover > a,#cssmenu ul li.active a{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.button:after{
    border-top:2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    border-bottom:2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.button.menu-opened:before{
    background:<?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
#cssmenu .submenu-button:after{
    background:<?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

#cssmenu .submenu-button:before{
    background:<?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.corp_icon .icon{
    border: 1px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.corp_icon .icon:hover{
    border: 6px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.corp_icon:hover .icon{
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.corp_icon .icon i {
   background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.skillbar-bar {
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.awesome{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.corpo_icon_box.red > .icon > i {
    background-color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.corpo_icon_box > .icon > i {
    background-color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.corpo_icon_box .icon{
    border: 1px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.corpo_icon_box:hover .icon{
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.corpo_icon_box .icon i {
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}


.t-bg a, .ti-bg a {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.t-bg a, .ti-bg a:hover {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?> !important;
}

.testimonial{
    border-left: 4px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.testimonial:before{
    border-top: 25px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.testimonial .title{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.testimonial .post{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.owl-theme .owl-controls .owl-page span{
    border: 2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.owl-theme .owl-controls .owl-page.active span,
.owl-theme .owl-controls .owl-page:hover span{
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.about_icon_i{
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.btn-default.active.focus, .btn-default.active:focus, .btn-default.active:hover, .btn-default:active.focus, .btn-default:active:focus, .btn-default:active:hover, .open>.dropdown-toggle.btn-default.focus, .open>.dropdown-toggle.btn-default:focus, .open>.dropdown-toggle.btn-default:hover {

    background-color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    border-color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.btn-default.active, .btn-default:active, .open>.dropdown-toggle.btn-default {
    background-color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    border-color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.btn-default.focus, .btn-default:focus {
    background-color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    border-color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.filter-button:hover
{
    border: 1px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    background-color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.btn-default:active .filter-button:active
{
    background-color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.contact_icon{
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.form-material .form-control:focus~.form-bar:before, .form-material .form-control:focus~.form-bar:after {
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.form-material .form-control:focus~label {
     color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.contact_btn:hover {
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    border: 2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.contact_icon_border{
    border: 2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.pagination>li>a:focus, .pagination>li>a:hover, .pagination>li>span:focus, .pagination>li>span:hover {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
ul.pagination li a.active {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.category_title {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.archives li a:hover {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.post_p:hover {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.blog_comment_title {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.blog_a {
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    border: 2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.blog_a:hover {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.hvr-bounce-to-right:before {
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.wpcf7 input[type="submit"]:hover,
.wpcf7 input[type="button"]:hover { 
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    border: 2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

#cssmenu > .menu-menu-1-container > ul > li:hover > a,#cssmenu .menu-menu-1-container > ul li.active a{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;

}
.button:after{
    border-top:2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    border-bottom:2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.button:before{
    background:<?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.button.menu-opened:after{
    background:<?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.button.menu-opened:before{
    background:<?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

#cssmenu .submenu-button:after{
    background:<?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

#cssmenu .submenu-button:before{
    background:<?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.submit{
    background: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
    border: 2px solid <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.submit:hover {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.button:before{
    background:<?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.button.menu-opened:after{
    background:<?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.comment-reply-title,.comments-title{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.widget-title{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}
.widget ul li a:hover {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}

.page-numbers:hover {
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;

}
.current{
    color: <?php if(ot_get_option('theme_color')!==''){ echo ot_get_option( 'theme_color'); }else{?> #e00000 <?php } ?>;
}


.overlay1 {

    <?php
if(ot_get_option('theme_color')!==''){ 
    $color=ot_get_option( 'theme_color');
    $rgba = hex2rgba($color,0.65); 
}
else{ 
$color='#e00000';
$rgba = hex2rgba($color, 0.65);
} ?>

  background-color: <?php echo $rgba; ?>;
  }

.overlay {
  
   <?php
if(ot_get_option('theme_color')!==''){ 
    $color=ot_get_option( 'theme_color');
    $rgba = hex2rgba($color,0.82); 
}
else{ 
$color='#e00000';
$rgba = hex2rgba($color, 0.82);
} ?>

  background-color: <?php echo $rgba; ?>;  
}

.corpo_icon_box.red > .icon:after {
<?php
if(ot_get_option('theme_color')!==''){ 
    $color=ot_get_option( 'theme_color');
    $rgba = hex2rgba($color,0.54); 
}
else{ 
$color='#e00000';
$rgba = hex2rgba($color, 0.54);
} ?>

    background-color: <?php echo $rgba; ?>;  
}

.corpo_icon_box.red > .icon:after {
<?php
if(ot_get_option('theme_color')!==''){ 
    $color=ot_get_option( 'theme_color');
    $rgba = hex2rgba($color,0.54); 
}
else{ 
$color='#e00000';
$rgba = hex2rgba($color, 0.54);
} ?>

    background-color: <?php echo $rgba; ?>;  
}

.corpo_icon_box > .icon:after {

<?php
if(ot_get_option('theme_color')!==''){ 
    $color=ot_get_option( 'theme_color');
    $rgba = hex2rgba($color,0.3); 
}
else{ 
$color='#e00000';
$rgba = hex2rgba($color, 0.3);
} ?>


    background-color: <?php echo $rgba; ?>;  
}

.corpo_icon_box> .icon {

<?php
if(ot_get_option('theme_color')!==''){ 
    $color=ot_get_option( 'theme_color');
    $rgba = hex2rgba($color,0.52); 
}
else{ 
$color='#e00000';
$rgba = hex2rgba($color, 0.52);
} ?>

    background-color: <?php echo $rgba; ?>; 
}

    </style>

<?php }

add_action('wp_head', 'yourtheme_customize_css');


/**********************************************************************************************************************************************************/

/*
======================
ADDING CUSTOM CSS AND JAVASCRIPT IN OPTION TREE
======================
*/

function css() {
    if (ot_get_option('custom_css', false) != false) {
            echo'<style>'.ot_get_option('custom_css').'</style>';   
        }
    }

add_action( 'wp_head', 'css', 100 );

function js() {
    if (ot_get_option('custom_js', false) != false) {
            echo'<script type="text/javascript" charset="utf-8">'.ot_get_option('custom_js').'</script>'; 

        }
    }

add_action( 'wp_head', 'js', 101);

/**********************************************************************************************************************************************************/

/*
======================
ADDING FOOTER WIDGETS
======================
*/

//AREA 1
register_sidebar(array(
    'name' => 'Footer Area',
    'id' => 'footer_area_widget',
    'description' => 'Footer Area Widgets',
));

/**********************************************************************************************************************************************************/


/*
======================
COMMENTS DESIGN
======================
*/

function wpb_move_comment_field_to_bottom( $fields ) {
$comment_field = $fields['comment'];
unset( $fields['comment'] );
$fields['comment'] = $comment_field;
return $fields;
}
 
add_filter( 'comment_form_fields', 'wpb_move_comment_field_to_bottom' );

/**********************************************************************************************************************************************************/
/*
======================
BREADCRUMB
======================
*/

function get_breadcrumb() {
    echo '<a href="'.home_url().'" rel="nofollow" class="white" >Home</a>';
    if (is_category() || is_single()) {
        // echo "&nbsp;&nbsp;&#47;&nbsp;&nbsp;";
        // the_category(' &bull; ');
            if (is_single()) {
                echo " &nbsp;&nbsp;&#47;&nbsp;&nbsp; ";
                the_title();
            }
    } elseif (is_page()) {
        echo "&nbsp;&nbsp;&#47;&nbsp;&nbsp;";
        echo the_title();
    } elseif (is_search()) {
        echo "&nbsp;&nbsp;&#47;&nbsp;&nbsp;Search Results for... ";
        echo '"<em>';
        echo the_search_query();
        echo '</em>"';
    }  elseif (is_404()) {
        echo "&nbsp;&nbsp;&#47;&nbsp;&nbsp;";
        echo "404";
    } elseif (is_home() || is_archive() || is_author() || is_category() || is_tag()) {
        echo "&nbsp;&nbsp;&#47;&nbsp;&nbsp;";
        echo "Blog";
    }
}
/**********************************************************************************************************************************************************/

/*
======================
PAGINATION
======================
*/

if ( ! function_exists( 'post_pagination' ) ) :
   function post_pagination() {
     global $wp_query;
     $pager = 999999999; // need an unlikely integer

        echo paginate_links( array(
             'base' => str_replace( $pager, '%#%', esc_url( get_pagenum_link( $pager ) ) ),
             'format' => '?paged=%#%',
             'current' => max( 1, get_query_var('paged') ),
             'total' => $wp_query->max_num_pages
        ) );
   }
endif;




